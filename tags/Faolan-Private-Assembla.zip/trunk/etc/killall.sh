#! /bin/bash

killall AgentServer
killall CSPlayerAgent
killall PlayerAgent
killall UniverseAgent
killall WorldServer