#! /bin/bash

./AgentServer &
./CSPlayerAgent &
./PlayerAgent &
./UniverseAgent &
./WorldServer &