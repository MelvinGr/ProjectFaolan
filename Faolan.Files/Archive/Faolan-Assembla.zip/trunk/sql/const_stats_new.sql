/*
MySQL Data Transfer
Source Host: localhost
Source Database: faolan
Target Host: localhost
Target Database: faolan
Date: 2010-02-26 21:54:34
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for const_stats
-- ----------------------------
CREATE TABLE `const_stats` (
  `level` int(11) NOT NULL,
  `race` int(11) NOT NULL,
  `class` int(11) NOT NULL,
  `health` int(11) NOT NULL,
  `mana` int(11) NOT NULL,
  `stamina` int(11) NOT NULL,
  `exp` int(11) NOT NULL DEFAULT '100',
  `S` int(11) NOT NULL,
  `I` int(11) NOT NULL,
  `C` int(11) NOT NULL,
  `D` int(11) NOT NULL,
  `W` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `const_stats` VALUES ('1', '1', '18', '110', '0', '172', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('2', '1', '18', '147', '0', '200', '240', '4', '2', '2', '3', '2');
INSERT INTO `const_stats` VALUES ('3', '1', '18', '184', '0', '228', '400', '7', '2', '4', '6', '2');
INSERT INTO `const_stats` VALUES ('1', '1', '24', '80', '165', '120', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('2', '1', '24', '90', '193', '130', '240', '3', '3', '2', '2', '3');
INSERT INTO `const_stats` VALUES ('3', '1', '24', '100', '221', '140', '400', '6', '4', '4', '4', '6');
