/*
MySQL Data Transfer
Source Host: localhost
Source Database: test
Target Host: localhost
Target Database: test
Date: 2010-01-22 00:15:18
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for accounts
-- ----------------------------
CREATE TABLE `accounts` (
  `account_id` int(10) unsigned NOT NULL,
  `username` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `mail` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `kind` tinyint(3) unsigned NOT NULL,
  `cookie` int(10) unsigned DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `last_connection` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `last_ip` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `date_creation` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `date_modif` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- ----------------------------
-- Table structure for archetypes
-- ----------------------------
CREATE TABLE `archetypes` (
  `arche_id` tinyint(3) unsigned NOT NULL,
  `arche_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `arche_desc` text COLLATE latin1_general_ci,
  PRIMARY KEY (`arche_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- ----------------------------
-- Table structure for body
-- ----------------------------
CREATE TABLE `body` (
  `character_id` smallint(5) NOT NULL,
  `arm` double(3,2) NOT NULL,
  `chest` double(3,2) NOT NULL,
  `bosom` double(3,2) NOT NULL,
  `stomach` double(3,2) NOT NULL,
  `arse` double(3,2) NOT NULL,
  `thigh` double(3,2) NOT NULL,
  `leg` double(3,2) NOT NULL,
  PRIMARY KEY (`character_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- ----------------------------
-- Table structure for characters
-- ----------------------------
CREATE TABLE `characters` (
  `character_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `name` char(255) COLLATE latin1_general_ci NOT NULL,
  `race` int(11) NOT NULL,
  `class` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `sex` int(11) NOT NULL,
  `realm_id` int(11) NOT NULL,
  `map_id` int(11) NOT NULL,
  `language` char(255) COLLATE latin1_general_ci NOT NULL,
  `headmesh` int(11) NOT NULL,
  `size` int(11) NOT NULL,
  `voice` int(11) NOT NULL,
  `last_connection` char(255) COLLATE latin1_general_ci NOT NULL,
  `pos_x` int(11) NOT NULL,
  `pos_y` int(11) NOT NULL,
  `pos_z` int(11) NOT NULL,
  `lbinprv` int(11) NOT NULL,
  PRIMARY KEY (`character_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- ----------------------------
-- Table structure for classes
-- ----------------------------
CREATE TABLE `classes` (
  `class_id` tinyint(3) unsigned NOT NULL,
  `class_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `class_desc` text COLLATE latin1_general_ci,
  `class_client_id` tinyint(3) NOT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- ----------------------------
-- Table structure for face
-- ----------------------------
CREATE TABLE `face` (
  `character_id` tinyint(5) NOT NULL,
  `EyebrowScale` double(3,2) NOT NULL,
  `CheekDepth` double(3,2) NOT NULL,
  `CheekHeight` double(3,2) NOT NULL,
  `CheekWidth` double(3,2) NOT NULL,
  `ChinLength` double(3,2) NOT NULL,
  `ChinWidth` double(3,2) NOT NULL,
  `EarAngle` double(3,2) NOT NULL,
  `Ears` double(3,2) NOT NULL,
  `EyesAngle` double(3,2) NOT NULL,
  `EyesVerticalPos` double(3,2) NOT NULL,
  `EyesHorizontalPos` double(3,2) NOT NULL,
  `EyesDepth` double(3,2) NOT NULL,
  `JawWidth` double(3,2) NOT NULL,
  `FaceLength` double(3,2) NOT NULL,
  `MouthVerticalPos` double(3,2) NOT NULL,
  `MouthWidth` double(3,2) NOT NULL,
  `NoseAngle` double(3,2) NOT NULL,
  `NoseCurve` double(3,2) NOT NULL,
  `Crooked_Nose` double(3,2) NOT NULL,
  `NoseLength` double(3,2) NOT NULL,
  `NoseWidth` double(3,2) NOT NULL,
  PRIMARY KEY (`character_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- ----------------------------
-- Table structure for maps
-- ----------------------------
CREATE TABLE IF NOT EXISTS `maps` (
  `map_id` int(11) NOT NULL,
  `map_name` varchar(150) collate latin1_general_ci default NULL,
  `position_0` int(11) NOT NULL,
  `position_1` int(11) NOT NULL,
  `position_2` int(11) NOT NULL,
  `rotation_0` int(11) NOT NULL,
  `rotation_1` int(11) NOT NULL,
  `rotation_2` int(11) NOT NULL,
  PRIMARY KEY  (`map_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- ----------------------------
-- Table structure for npcs
-- ----------------------------
CREATE TABLE IF NOT EXISTS `npcs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `nameId` bigint(12) NOT NULL default '0',
  `map` int(11) NOT NULL,
  `action` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `fraction` int(11) NOT NULL default '0',
  `health` int(11) NOT NULL default '0',
  `stamina` int(11) NOT NULL default '0',
  `mana` int(11) NOT NULL default '0',
  `getExp` int(11) NOT NULL default '0',
  `extras` longtext NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for npc_details
-- ----------------------------
CREATE TABLE IF NOT EXISTS `npc_details` (
  `id` int(11) NOT NULL default '0',
  `position_x` bigint(12) NOT NULL default '0',
  `position_y` bigint(12) NOT NULL default '0',
  `position_z` bigint(12) NOT NULL default '0',
  `rotation_x` bigint(12) NOT NULL default '0',
  `rotation_y` bigint(12) NOT NULL default '0',
  `rotation_z` bigint(12) NOT NULL default '0',
  `bodymesh` int(11) NOT NULL default '0',
  `headmesh` int(11) NOT NULL default '0',
  `hairmesh` int(11) NOT NULL default '0',
  `beardmesh` int(11) NOT NULL default '0',
  `npcsize` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for npc_items
-- ----------------------------
CREATE TABLE IF NOT EXISTS `npc_items` (
  `id` int(11) NOT NULL default '0' COMMENT 'ID of npc',
  `neck` bigint(12) NOT NULL default '0' COMMENT '0x01',
  `head` bigint(12) NOT NULL default '0' COMMENT '0x02',
  `tokens` bigint(12) NOT NULL default '0' COMMENT '0x03',
  `chest` bigint(12) NOT NULL default '0' COMMENT '0x05',
  `main_hand_left` bigint(12) NOT NULL default '0' COMMENT '0x06',
  `belt` bigint(12) NOT NULL default '0' COMMENT '0x07',
  `off_hand_left` bigint(12) NOT NULL default '0' COMMENT '0x08',
  `ring_left` bigint(12) NOT NULL default '0' COMMENT '0x09',
  `ring_right` bigint(12) NOT NULL default '0' COMMENT '0x0a',
  `cloak` bigint(12) NOT NULL default '0' COMMENT '0x0b',
  `shoulder` bigint(12) NOT NULL default '0' COMMENT '0x0c',
  `boots` bigint(12) NOT NULL default '0' COMMENT '0x0e',
  `hands` bigint(12) NOT NULL default '0' COMMENT '0x0f',
  `legs` bigint(12) NOT NULL default '0' COMMENT '0x10',
  `first_pos_bag` bigint(12) NOT NULL default '0' COMMENT '0x11',
  `wrist` bigint(12) NOT NULL default '0' COMMENT '0x12',
  `main_hand_right` bigint(12) NOT NULL default '0' COMMENT '0x14',
  `off_hand_right` bigint(12) NOT NULL default '0' COMMENT '0x15',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for race_arche_class
-- ----------------------------
CREATE TABLE `race_arche_class` (
  `race_id` tinyint(3) unsigned NOT NULL,
  `arche_id` tinyint(3) unsigned NOT NULL,
  `class_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`race_id`,`arche_id`,`class_id`),
  KEY `fk_RAC_arche` (`arche_id`),
  KEY `fk_RAC_class` (`class_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- ----------------------------
-- Table structure for races
-- ----------------------------
CREATE TABLE `races` (
  `race_id` tinyint(3) unsigned NOT NULL,
  `race_name` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `race_desc` text COLLATE latin1_general_ci,
  PRIMARY KEY (`race_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- ----------------------------
-- Table structure for const_abilitys
-- ----------------------------
DROP TABLE IF EXISTS `const_abilitys`;
CREATE TABLE IF NOT EXISTS `const_abilitys` (
  `class` int(12) NOT NULL DEFAULT '0',
  `level` int(12) NOT NULL DEFAULT '0',
  `abilitys` longtext,
  `abilitysNew` longtext,
  `spells` longtext,
  `spellsNew` longtext
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for const_stats
-- ----------------------------
DROP TABLE IF EXISTS `const_stats`;
CREATE TABLE IF NOT EXISTS `const_stats` (
  `level` int(11) NOT NULL,
  `race` int(11) NOT NULL,
  `class` int(11) NOT NULL,
  `health` int(11) NOT NULL,
  `mana` int(11) NOT NULL,
  `stamina` int(11) NOT NULL,
  `exp` int(11) NOT NULL DEFAULT '100',
  `S` int(11) NOT NULL,
  `I` int(11) NOT NULL,
  `C` int(11) NOT NULL,
  `D` int(11) NOT NULL,
  `W` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for p_abilities
-- ----------------------------
CREATE TABLE `p_abilities` (
  `name` text,
  `id` int(11) NOT NULL default '0',
  `level` tinyint(11) default NULL,
  `data0` bigint(12) default NULL,
  `data1` bigint(12) default NULL,
  `data2` bigint(12) default NULL,
  `data3` bigint(12) default NULL,
  `data4` bigint(12) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for p_abilities
-- ----------------------------
DROP TABLE IF EXISTS `player_items`;
CREATE TABLE IF NOT EXISTS `player_items` (
  `id` int(11) NOT NULL DEFAULT '0' COMMENT 'ID from player',
  `neck` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x01',
  `head` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x02',
  `tokens` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x03',
  `chest` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x05',
  `main_hand_left` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x06',
  `belt` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x07',
  `off_hand_left` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x08',
  `ring_left` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x09',
  `ring_right` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x0a',
  `cloak` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x0b',
  `shoulder` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x0c',
  `boots` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x0e',
  `hands` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x0f',
  `legs` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x10',
  `first_pos_bag` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x11',
  `wrist` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x12',
  `main_hand_right` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x14',
  `off_hand_right` bigint(12) NOT NULL DEFAULT '0' COMMENT '0x15',
  `bag` longtext,
  `quest` longtext,
  `ressources` longtext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `accounts` VALUES ('1', 'root', 'toor', null, '0', '404', '0', '19/12/2009', '127.0.0.1', '10/09/2009', '10/09/2009');
INSERT INTO `archetypes` VALUES ('1', 'Priest', null);
INSERT INTO `archetypes` VALUES ('2', 'Soldier', null);
INSERT INTO `archetypes` VALUES ('3', 'Rogue', null);
INSERT INTO `archetypes` VALUES ('4', 'Mage', null);
INSERT INTO `classes` VALUES ('1', 'Priest of Mitra', null, '24');
INSERT INTO `classes` VALUES ('2', 'Tempest of Set', null, '28');
INSERT INTO `classes` VALUES ('3', 'Bear Shaman', null, '29');
INSERT INTO `classes` VALUES ('4', 'Conqueror', null, '22');
INSERT INTO `classes` VALUES ('5', 'Dark Templar', null, '31');
INSERT INTO `classes` VALUES ('6', 'Guardian', null, '20');
INSERT INTO `classes` VALUES ('7', 'Barbarian', null, '18');
INSERT INTO `classes` VALUES ('8', 'Ranger', null, '39');
INSERT INTO `classes` VALUES ('9', 'Assassin', null, '34');
INSERT INTO `classes` VALUES ('10', 'Herald of Xotli', null, '43');
INSERT INTO `classes` VALUES ('11', 'Demonologist', null, '44');
INSERT INTO `classes` VALUES ('12', 'Necromancer', null, '41');
INSERT INTO `maps` VALUES('4010', 'Tortage Beach', '1134641152', '1125207987', '1144011162', '0', '0', '0');
INSERT INTO `maps` VALUES('4025', 'Acheronian Ruins', '1114187917', '1124053233', '1134462075', '1056274244', '1063299392', '1793');
INSERT INTO `npcs` VALUES('433435', 'Scavenger Lackey', '12141', '4010', '3', '1', '1', '59', '59', '59', '50', '');
INSERT INTO `npcs` VALUES('433433', 'Scavenger Lackey', '12141', '4010', '3', '1', '1', '59', '59', '59', '50', '');
INSERT INTO `npcs` VALUES('433376', 'Kalanthes', '2704', '4010', '1', '80', '0', '3855', '3855', '3855', '0', '');
INSERT INTO `npcs` VALUES('433474', 'Casilda', '9411', '4010', '1', '1', '0', '59', '59', '59', '0', '1::GameAgent<->GameInterface<->0<->74<->642cd3d60000c35000069d4200040000000500026ec4000000000000000200000018000011b800000000000000000000000000000000000000000000000000000000000000003e4f4f3c');
INSERT INTO `npc_details` VALUES('433435', '1134607368', '1125238684', '1143222632', '1054102189', '1063842617', '1536', '140327', '191546', '13', '0', '100');
INSERT INTO `npc_details` VALUES('433433', '1134021280', '1125247291', '1143100195', '1054102189', '1063842617', '2816', '701595', '222567', '149', '0', '100');
INSERT INTO `npc_details` VALUES('433376', '1134991770', '1125272562', '1144029610', '1059471930', '3208817143', '11776', '137506', '160655', '0', '0', '100');
INSERT INTO `npc_details` VALUES('433474', '1135923790', '1125734178', '1144220353', '1063106982', '3204443122', '85760', '701595', '222567', '0', '0', '100');
INSERT INTO `npc_items` VALUES('433433', '0', '0', '0', '189905', '195325', '194918', '195325', '0', '0', '0', '0', '189896', '0', '193680', '0', '116743', '0', '0');
INSERT INTO `npc_items` VALUES('433435', '0', '0', '0', '189905', '195325', '194918', '195325', '0', '0', '0', '0', '0', '0', '193680', '0', '0', '0', '0');
INSERT INTO `npc_items` VALUES('433376', '0', '0', '0', '189905', '195325', '0', '0', '0', '0', '0', '0', '0', '0', '193680', '0', '0', '0', '0');
INSERT INTO `npc_items` VALUES('433474', '0', '0', '0', '189905', '195325', '194918', '195325', '0', '0', '0', '0', '189896', '0', '193680', '0', '116743', '0', '0');
INSERT INTO `race_arche_class` VALUES ('1', '1', '1');
INSERT INTO `race_arche_class` VALUES ('1', '2', '4');
INSERT INTO `race_arche_class` VALUES ('1', '2', '5');
INSERT INTO `race_arche_class` VALUES ('1', '2', '6');
INSERT INTO `race_arche_class` VALUES ('1', '3', '7');
INSERT INTO `race_arche_class` VALUES ('1', '3', '8');
INSERT INTO `race_arche_class` VALUES ('1', '3', '9');
INSERT INTO `race_arche_class` VALUES ('2', '1', '3');
INSERT INTO `race_arche_class` VALUES ('2', '2', '4');
INSERT INTO `race_arche_class` VALUES ('2', '2', '5');
INSERT INTO `race_arche_class` VALUES ('2', '2', '6');
INSERT INTO `race_arche_class` VALUES ('2', '3', '7');
INSERT INTO `race_arche_class` VALUES ('2', '3', '8');
INSERT INTO `race_arche_class` VALUES ('3', '1', '2');
INSERT INTO `race_arche_class` VALUES ('3', '3', '8');
INSERT INTO `race_arche_class` VALUES ('3', '3', '9');
INSERT INTO `race_arche_class` VALUES ('3', '4', '10');
INSERT INTO `race_arche_class` VALUES ('3', '4', '11');
INSERT INTO `race_arche_class` VALUES ('3', '4', '12');
INSERT INTO `races` VALUES ('1', 'Aquilonian', null);
INSERT INTO `races` VALUES ('2', 'Cimmerian', null);
INSERT INTO `races` VALUES ('3', 'Stygian', null);
INSERT INTO `characters` VALUES ('2018', '1', 'Conanhimself', '1', '18', '1', '2', '1', '4010', 'enEN', '793613', '95', '2', '00-00-0000 00:00', '1134641152', '1125207987', '1144011162', '112233');
INSERT INTO `const_stats` VALUES ('1', '1', '18', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '1', '20', '130', '0', '179', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '2', '22', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '2', '24', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '2', '28', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '1', '29', '118', '171', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '1', '31', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '1', '34', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '1', '39', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '1', '41', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '1', '43', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '1', '44', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '2', '18', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '2', '20', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '1', '22', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '1', '24', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '1', '28', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '2', '29', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '2', '31', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '2', '34', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '2', '39', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '2', '41', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '2', '43', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '2', '44', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '3', '18', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '3', '20', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '3', '22', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '3', '24', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '3', '28', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '3', '29', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '3', '31', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '3', '34', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '3', '39', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '3', '41', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '3', '43', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('1', '3', '44', '118', '0', '176', '100', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('2', '1', '18', '163', '0', '218', '240', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('3', '1', '18', '216', '0', '262', '400', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('2', '1', '29', '136', '209', '203', '240', '1', '1', '1', '1', '1');
INSERT INTO `const_stats` VALUES ('2', '1', '20', '195', '0', '218', '240', '1', '1', '1', '1', '1');
INSERT INTO `maps` VALUES ('500', 'GM Island', '1133136232', '1102708380', '1135420002', '0', '0', '0');
INSERT INTO `maps` VALUES ('2070', 'Poitain', '1151341050', '1127124818', '1152928673', '0', '0', '0');
INSERT INTO `maps` VALUES ('1000', 'Conarch Village', '1114641152', '1114053233', '1144011162', '0', '0', '0');
INSERT INTO `maps` VALUES ('2000', 'Old Tarantia', '1146428220', '1120564870', '1140034652', '0', '0', '0');
INSERT INTO `maps` VALUES ('3020', 'Khopshef Province', '1141409216', '1094408432', '1149125668', '0', '0', '0');
INSERT INTO `p_abilities` VALUES('Normal Attack Left', '769094', '1', '1263352118', '3236668225', '2153842419', '314062142', '3015939650');
INSERT INTO `p_abilities` VALUES('Normal Attack Front', '769099', '1', '1227967307', '3443694845', '1660108369', '1296666148', '2957995211');
INSERT INTO `const_abilitys` VALUES (29, 1, '769094_1-769099_1', NULL, '165241', NULL);
INSERT INTO `const_abilitys` VALUES (44, 1, '769094_1-769099_1', NULL, NULL, NULL);
INSERT INTO `const_abilitys` VALUES (18, 1, '769094_1-769099_1', NULL, NULL, NULL);