/*
Project Faolan a Simple and Free Server Emulator for Age of Conan.
Copyright (C) 2009, 2010 The Project Faolan Team

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "WorldServer.h"

void WorldServer::LoadNearNPCs(GameClient* client)
{
	Database.getNpcs(client->charInfo.map, &client->datastoreNpcs);

	if(client->datastoreNpcs.size() > 0)
	{
		for(uint32 i = 0; i < client->datastoreNpcs.size(); i++)
		{
			if(client->charInfo.position.distance(client->datastoreNpcs[i].position) < maxDistance && 
				!checkAlreadySpawned(client->spawnedMobs, client->datastoreNpcs[i].npcId))
			{
				vector<Item> npcItems;
				Database.getNpcItems(client->datastoreNpcs[i].npcId, &npcItems);
				//new
				uint8 ending[] = 
				{
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x3e, 0x4f, 0x4f, 0x3c
				};

				uint8 enemy0_0[] = {
					0x10, 0x00, 
					0x00, 0x01, 0x02, 0x18, 
					0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 
					0x00, 0x00, 0x30, 0xc8, 
					0x01, 
					0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0xa4, 0x28, 
					0x00, 0x00, 0x00, 0x00, 
					0x01, 
					0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x00, 
					0x00
				};
				uint8 enemy0_1[] = {
					0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x01, 
					0x02
				};
				uint8 enemy0_2[] = {
					0x00, 0x00, 0x00, 0x00, 
					0x00, 0x04, 
					0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00
				};
				uint8 enemy0_3[] = {
					0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x64, 
					0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 
					0x00, 0x00, 0x00, 0x05, 
					0x00, 0x00, 0x00, 0x02, 
					0x00
				};
				uint8 enemy0_4[] = {
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x00, 


					0x00, 0x00, 0x00, 0x00 //16
					/*
					0x00, 0x00, 0x00, 0x09, 0x3f, 0x47, 0xea, 0x4f, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x0e, 0x3f, 0x2e, 0x96, 0x2d, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x14, 0x3e, 0xfb, 0x7a, 0x1c, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x16, 0x3d, 0xb5, 0x2a, 0xe7, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x19, 0x3e, 0xcb, 0x05, 0xae, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x1b, 0x3e, 0xe5, 0xc4, 0x44, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x1e, 0x3e, 0xa1, 0x04, 0x92, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x1f, 0x3f, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x23, 0x3e, 0x94, 0x5a, 0x81, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x24, 0x3e, 0x96, 0x29, 0x95, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x01, 0x04, 0x3e, 0x01, 0x95, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x01, 0x02, 0xbf, 0x42, 0x7c, 0xd0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x01, 0x01, 0xbd, 0x3c, 0x27, 0x63, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x01, 0x05, 0xbe, 0x0d, 0x1e, 0x09, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
					//*/
				};
				uint8 enemy0_5[] = {
					0x00, 0x00, 0x03, 0xf1, 

					0x00, 0x00, 0x00, 0x02, 
					0x00, 0x00, 0x00, 0x78, 
					0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x00, 0x00, 
					0x00, 0x00, 0x03, 0xf1
				};

				client->datastoreNpcs[i].move.isMoving = false;
				client->datastoreNpcs[i].attackMode = false;

				PacketBuffer aBuffer(10000);
				aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00); // PassBlob
				uint32 size=0;
				/*
				Log.Notice("Char details\nLevel: %i\nBody: %i\nHead: %i\nHair: %i\nSize:%i\nFraction: %i\nHealth: %i\n Stamina: %i\nMana: %i\nItems: %i\n\n", 
					client->datastoreNpcs[i].level, client->datastoreNpcs[i].bodyMesh, client->datastoreNpcs[i].headMesh, client->datastoreNpcs[i].hairMesh, 
					client->datastoreNpcs[i].size, client->datastoreNpcs[i].fraction, client->datastoreNpcs[i].health,
					client->datastoreNpcs[i].stamina, client->datastoreNpcs[i].mana, npcItems.size());
				//*/
				size = sizeof(enemy0_0) + sizeof(enemy0_1) + sizeof(enemy0_2) + sizeof(enemy0_3) + sizeof(enemy0_4) + sizeof(enemy0_5);
				size += (30 * 4) + (5 * 2) + (4 * 1) + sizeof(ending) + 2 + client->datastoreNpcs[i].name.size() + (14 * 4 * npcItems.size());
			
				//*/
				aBuffer.write<uint32>(size);
				aBuffer.write<uint32>(0xfa015807);
				aBuffer.write<uint32>(0x0000c350);
				aBuffer.write<uint32>(client->datastoreNpcs[i].npcId);
				aBuffer.write<uint16>(0x0002);
				aBuffer.write<uint8>(0x2a);
				aBuffer.write<uint32>(0x00000030);
				aBuffer.write<uint32>(0x00000070);
				aBuffer.write<uint32>(0x00006188);
				aBuffer.write<uint32>(0x00002700);
				aBuffer.write<uint32>(0x00000350);
				aBuffer.write<uint8>(0x41);
				aBuffer.write<uint32>(0x00038c65); //instance
				aBuffer.write<uint32>(0x080ac283);
				aBuffer.write<uint32>(client->datastoreNpcs[i].position.x);
				aBuffer.write<uint32>(client->datastoreNpcs[i].position.y);
				aBuffer.write<uint32>(client->datastoreNpcs[i].position.z);
				aBuffer.write<uint32>(0);
				aBuffer.write<uint32>(client->datastoreNpcs[i].rotation.x);
				aBuffer.write<uint32>(0);
				aBuffer.write<uint32>(client->datastoreNpcs[i].rotation.y);
				aBuffer.write<uint32>(client->datastoreNpcs[i].rotation.z);
				aBuffer.write<string>(client->datastoreNpcs[i].name);
				
				aBuffer.writeArray(enemy0_0, sizeof(enemy0_0));
				aBuffer.write<uint32>((client->datastoreNpcs[i].stamina * 100));
				aBuffer.write<uint32>((client->datastoreNpcs[i].stamina * 100));
				aBuffer.write<uint32>((client->datastoreNpcs[i].mana * 100));
				aBuffer.write<uint32>((client->datastoreNpcs[i].mana * 100));
				if(client->datastoreNpcs[i].fraction > 0)
				{
					aBuffer.write<uint8>(0x00);
				}
				else
				{
					aBuffer.write<uint8>(0x01);
				}
				aBuffer.write<uint32>(client->datastoreNpcs[i].action);
				aBuffer.writeArray(enemy0_1, sizeof(enemy0_1));
				aBuffer.write<uint32>(client->datastoreNpcs[i].nameId);
				aBuffer.writeArray(enemy0_2, sizeof(enemy0_2));
				aBuffer.write<uint16>(client->datastoreNpcs[i].level);
				aBuffer.write<uint16>(client->datastoreNpcs[i].level);
				aBuffer.write<uint32>((client->datastoreNpcs[i].health * 100));
				aBuffer.write<uint32>((client->datastoreNpcs[i].health * 100));
				aBuffer.write<uint16>(0x0032);
				//aBuffer.writeArray(enemy0_2, sizeof(enemy0_2)); 112
				aBuffer.write<uint32>(client->datastoreNpcs[i].bodyMesh);
				aBuffer.write<uint16>(client->datastoreNpcs[i].size);
				aBuffer.writeArray(enemy0_3, sizeof(enemy0_3));
				aBuffer.write<uint32>(client->datastoreNpcs[i].headMesh);
				aBuffer.write<uint32>(0x000003f1);
				aBuffer.write<uint8>(0x01);

				aBuffer.write<uint32>(npcItems.size());
				for(uint32 c = 0; c < npcItems.size(); c++)
				{
					aBuffer.write<uint32>(npcItems.at(c).pos);
					aBuffer.write<uint32>(npcItems.at(c).id);
					aBuffer.write<uint32>(npcItems.at(c).id);
					aBuffer.write<uint32>(npcItems.at(c).iLevel);
					aBuffer.write<uint32>(npcItems.at(c).data0);
					aBuffer.write<uint32>(npcItems.at(c).data1);
					aBuffer.write<uint32>(npcItems.at(c).data2);
					aBuffer.write<uint32>(npcItems.at(c).data3);
					aBuffer.write<uint32>(npcItems.at(c).data4);
					aBuffer.write<uint32>(npcItems.at(c).data1);
					aBuffer.write<uint32>(npcItems.at(c).data2);
					aBuffer.write<uint32>(npcItems.at(c).data3);
					aBuffer.write<uint32>(npcItems.at(c).data4);
					aBuffer.write<uint32>(0x000003f1);
				}

				aBuffer.writeArray(enemy0_4, sizeof(enemy0_4));
				//aBuffer.write<uint32>(client->datastoreNpcs[i].hairMesh);
				aBuffer.writeArray(enemy0_5, sizeof(enemy0_5));
				aBuffer.writeArray(ending, sizeof(ending));
				aBuffer.doItAll(client->clientSocket);

				aBuffer = PacketBuffer(500);
				aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00); // PassBlob
				aBuffer.write<uint32>(0x0000002d);	//size
				aBuffer.write<uint32>(0x96b8dc59);	//opcode
				aBuffer.write<uint32>(0x0000c350);
				aBuffer.write<uint32>(client->datastoreNpcs[i].npcId);
				aBuffer.write<uint8>(0);
				aBuffer.write<uint32>(0x00000003);
				aBuffer.write<uint32>(0x0000001b);
				aBuffer.write<uint32>((client->datastoreNpcs[i].curHealth * 100));
				aBuffer.write<uint32>(0x000001f8);
				aBuffer.write<uint32>((client->datastoreNpcs[i].stamina * 100));
				aBuffer.write<uint32>(0x000001fa);
				aBuffer.write<uint32>((client->datastoreNpcs[i].mana * 100));
				aBuffer.write<uint32>(0x3e4f4f3c);
				aBuffer.doItAll(client->clientSocket);

				if(client->datastoreNpcs[i].action == 1)
				{
					//nothing atm
				}
				else
				{
					uint8 spawn1[] = {
						0x00, 0x04, 
						0x00, 0x00, 0x00, 0x07, 
						0x00, 0x00, 0x42, 0x58, 
						0x00, 0x00, 0x00, 0x00, 
						0x00, 0x00, 0x00, 0x01, 
						0x00, 0x00, 0x00, 0x18, 
						0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3e, 0x4f, 0x4f, 0x3c
					};
					aBuffer = PacketBuffer(500);
					aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00); // PassBlob
					aBuffer.write<uint32>(0x0000002d);	//size
					aBuffer.write<uint32>(0x642cd3d6);	//opcode
					aBuffer.write<uint32>(0x0000c350);
					aBuffer.write<uint32>(client->datastoreNpcs[i].npcId);
					aBuffer.writeArray(spawn1, sizeof(spawn1));
					//aBuffer.doItAll(client->clientSocket);
				}

				if(client->datastoreNpcs[i].extras.size() > 0 && false)
				{
					vector<string> extras = String::splitString(client->datastoreNpcs[i].extras, "::");
					uint32 anzPackets = atoi(extras[0].c_str());
					if(anzPackets > 0)
					{
						for(uint32 x = 0; x < anzPackets; x++)
						{
							vector<string> packet = String::splitString(extras[x+1], "<->");
							aBuffer = PacketBuffer(5000);
							aBuffer.writeHeader(packet[0], packet[1], gameUnknown1, 0, client->nClientInst, 0, atoi(packet[2].c_str()));
							if(atoi(packet[3].c_str())>0)
							{
								uint8 toWrite;
								uint32 offset = 0;
								aBuffer.write<uint32>(atoi(packet[3].c_str()));
								for(int y = 0; y < atoi(packet[3].c_str()); y++)
								{
									uint8 conv[2];
									conv[0] = GetDigitValue(packet[4].c_str()[offset]);
									conv[1] = GetDigitValue(packet[4].c_str()[offset+1]);
									toWrite = (conv[0] * 16) + conv[1];
									offset += 2;
									toWrite &= 0x000000ff;
									aBuffer.write<uint8>(toWrite);
								}
								Log.Notice("\n");

							}
							aBuffer.doItAll(client->clientSocket);
						}
					}
				}
				//*/
			}
		}
	}
	else
	{
		Log.Warning("No NPCs in the Database!!!\n");
	}
}

bool WorldServer::checkAlreadySpawned(vector<uint32>* spawned, uint32 npcId)
{
	if(spawned->size() > 0)
	{
		for(uint32 x = 0; x < spawned->size(); x++)
			if(spawned->at(x) == npcId) 
				return true;
	}

	return false;
}
uint8 WorldServer::GetDigitValue (char digit)
{
	int asciiOffset, digitValue;
	if (digit >= 48 && digit <= 57)
	{
		// code for '0' through '9'
		asciiOffset = 48;
		digitValue = digit - asciiOffset;
		return digitValue;
	}
	else if (digit >= 65 && digit <= 70)
	{
		// digit is 'A' through 'F'
		asciiOffset = 55;
		digitValue = digit - asciiOffset;
		return digitValue;
	}
	else if (digit >= 97 && digit <= 102)
	{
		// code for 'a' through 'f'
		asciiOffset = 87;
		digitValue = digit - asciiOffset;
		return digitValue;
	}
	else
	{
		// illegal digit
		return 0;
	}
}

void WorldServer::eraseAllNpcs(GameClient* client)
{
	for(uint32 i = 0; i < client->spawnedMobs->size(); i++)
	{
		PacketBuffer aBuffer(5000);
		aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
		aBuffer.write<uint32>(0x00000015);
		aBuffer.write<uint32>(0x04b82b2d);
		aBuffer.write<uint32>(0x0000c350);
		aBuffer.write<uint32>(client->spawnedMobs->at(i));
		aBuffer.write<uint8>(0x01);
		aBuffer.write<uint32>(0x00038c65);
		aBuffer.write<uint32>(0x3e4f4f3c);
		aBuffer.doItAll(client->clientSocket);
	}

	client->spawnedMobs->clear();
}