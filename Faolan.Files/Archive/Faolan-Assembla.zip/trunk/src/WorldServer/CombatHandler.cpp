/*
Project Faolan a Simple and Free Servoer Emulator for Age of Conan.
Copyright (C) 2009, 2010 The Project Faolan Team

This program is free softvtare: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Softvtare Foundation, either voersion 3 of the License, or
(at your option) any later voersion.

This program is distributed in the hope that it vtill be useful,
but WITHOUT ANY WARRANTY; without evoen the implied vtarranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have receivoed a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "WorldServer.h"

void WorldServer::HitWithSpell(GameClient* client, Packet* packet)
{
	NPC curCombat = getNpcData(client, client->charInfo.combat.target);

	uint32 unk1 = packet->data->read<uint32>();
	uint32 cins = packet->data->read<uint32>();
	uint16 unk2 = packet->data->read<uint16>();
	uint32 unk3 = packet->data->read<uint32>();
	uint32 unk4 = packet->data->read<uint32>();
	uint32 unk5 = packet->data->read<uint32>();
	uint32 unk6 = packet->data->read<uint32>();
	uint32 unk7 = packet->data->read<uint32>();
	uint32 unk8 = packet->data->read<uint32>();
	uint32 unk9 = packet->data->read<uint32>();
	uint32 unk10 = packet->data->read<uint32>();
	uint32 unk11 = packet->data->read<uint32>();
	uint32 unk12 = packet->data->read<uint32>();
	uint32 unk13 = packet->data->read<uint32>();
	uint32 target = packet->data->read<uint32>();
	uint16 unk15 = packet->data->read<uint16>();
	uint8 unk16 = packet->data->read<uint8>();
	uint32 unk17 = packet->data->read<uint32>();
	uint32 unk18 = packet->data->read<uint32>();
	uint16 unk19 = packet->data->read<uint16>();
	uint32 unk20 = packet->data->read<uint32>();
	uint32 unk21 = packet->data->read<uint32>();
	uint32 unk22 = packet->data->read<uint32>();
	uint32 unk23 = packet->data->read<uint32>();
	uint8 unk24 = packet->data->read<uint8>();

	//Packet 596
	PacketBuffer aBuffer(500);
	aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
	aBuffer.write<uint32>(0x00000060);
	aBuffer.write<uint32>(0x642cd3d6);
	aBuffer.write<uint32>(unk1);
	aBuffer.write<uint32>(cins);
	aBuffer.write<uint16>(unk2 + 1);
	aBuffer.write<uint32>(unk3);
	aBuffer.write<uint32>(unk4);
	aBuffer.write<uint32>(unk5);
	aBuffer.write<uint32>(unk6);
	aBuffer.write<uint32>(unk7);
	aBuffer.write<uint32>(unk8);
	aBuffer.write<uint32>(unk9);
	aBuffer.write<uint32>(unk10);
	aBuffer.write<uint32>(unk11);
	aBuffer.write<uint32>(unk12);
	aBuffer.write<uint32>(unk13);
	aBuffer.write<uint32>(target);
	aBuffer.write<uint16>(unk15);
	aBuffer.write<uint8>(unk16);
	aBuffer.write<uint32>(unk17);
	aBuffer.write<uint32>(unk18);
	aBuffer.write<uint16>(unk19);
	aBuffer.write<uint32>(unk20);
	aBuffer.write<uint32>(unk21);
	aBuffer.write<uint32>(unk22);
	aBuffer.write<uint32>(unk23);
	aBuffer.write<uint8>(unk24);
	aBuffer.write<uint32>(0x3e4f4f3c);
	aBuffer.doItAll(client->clientSocket);

	aBuffer = PacketBuffer(500);
	aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
	aBuffer.write<uint32>(0x00000060);
	aBuffer.write<uint32>(0x642cd3d6);
	aBuffer.write<uint32>(unk1);
	aBuffer.write<uint32>(cins);
	aBuffer.write<uint16>(unk2 + 1);
	aBuffer.write<uint32>(unk3);
	aBuffer.write<uint32>(unk4);
	aBuffer.write<uint32>(unk5);
	aBuffer.write<uint32>(unk6);
	aBuffer.write<uint32>(unk7);
	aBuffer.write<uint32>(unk8);
	aBuffer.write<uint32>(unk9);
	aBuffer.write<uint32>(unk10);
	aBuffer.write<uint32>(unk11);
	aBuffer.write<uint32>(unk12);
	aBuffer.write<uint32>(unk13);
	aBuffer.write<uint32>(target);
	aBuffer.write<uint16>(unk15);
	aBuffer.write<uint8>(unk16);
	aBuffer.write<uint32>(unk17);
	aBuffer.write<uint32>(unk18);
	aBuffer.write<uint16>(unk19);
	aBuffer.write<uint32>(unk20);
	aBuffer.write<uint32>(unk21);
	aBuffer.write<uint32>(unk22);
	aBuffer.write<uint32>(unk23);
	aBuffer.write<uint8>(1);
	aBuffer.write<uint32>(0x3e4f4f3c);
	aBuffer.doItAll(client->clientSocket);

	aBuffer = PacketBuffer(500);
	aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
	aBuffer.write<uint32>(0x00000021);
	aBuffer.write<uint32>(0x0d155695);
	aBuffer.write<uint32>(0x0000c350);
	aBuffer.write<uint32>(target);
	aBuffer.write<uint8>(0x00);
	aBuffer.write<uint32>(0x0000c350);
	aBuffer.write<uint32>(cins);
	aBuffer.write<uint32>(0x00000000);
	aBuffer.write<uint32>(0x00000002);
	aBuffer.write<uint32>(0x3e4f4f3c);
	aBuffer.doItAll(client->clientSocket);

	aBuffer = PacketBuffer(500);
	aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
	aBuffer.write<uint32>(0x00000016);
	aBuffer.write<uint32>(0x1745ef6c);
	aBuffer.write<uint32>(0x0000c350);
	aBuffer.write<uint32>(cins);
	aBuffer.write<uint8>(0x00);
	aBuffer.write<uint32>(0x00000002);
	aBuffer.write<uint8>(0x00);
	aBuffer.write<uint32>(0x3e4f4f3c);
	aBuffer.doItAll(client->clientSocket);

	aBuffer = PacketBuffer(500);
	aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
	aBuffer.write<uint32>(0x0000001e);
	aBuffer.write<uint32>(0x8a01e5a1);
	aBuffer.write<uint32>(0x0000c350);
	aBuffer.write<uint32>(cins);
	aBuffer.write<uint16>(0x0000);
	aBuffer.write<uint32>(0x0000c350);
	aBuffer.write<uint32>(target);
	aBuffer.write<uint32>(0x00000001);
	aBuffer.write<uint32>(0x3e4f4f3c);
	aBuffer.doItAll(client->clientSocket);

	aBuffer = PacketBuffer(500);
	aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
	aBuffer.write<uint32>(0x00000016);
	aBuffer.write<uint32>(0x1745ef6c);
	aBuffer.write<uint32>(0x0000c350);
	aBuffer.write<uint32>(cins);
	aBuffer.write<uint8>(0x00);
	aBuffer.write<uint32>(0x00000002);
	aBuffer.write<uint8>(0x01);
	aBuffer.write<uint32>(0x3e4f4f3c);
	aBuffer.doItAll(client->clientSocket);
}

void WorldServer::HitEnemy(GameClient* client, Packet* packet)
{
	NPC curCombat = getNpcData(client, client->charInfo.combat.target);

	uint32 unk2 = 0;
	uint32 unk3 = 0;
	uint32 unk4 = 0;
	uint32 unk5 = 0;
	uint32 unk6 = 0;
	uint32 unk7 = 0;
	uint32 unk8 = 0;
	uint32 unk9 = 0;
	uint32 unk10 = 0;
	uint32 unk11 = 0;
	uint32 unk12 = 0;
	uint32 target = 0;
	uint32 unk13 = 0;
	uint32 unk14 = 0;
	uint32 unk15 = 0;
	uint32 unk16 = 0;
	uint32 unk17 = 0;

	try
	{
		unk2 = packet->data->read<uint32>();
		unk3 = packet->data->read<uint32>();
		unk4 = packet->data->read<uint32>();
		unk5 = packet->data->read<uint32>();
		unk6 = packet->data->read<uint32>();
		unk7 = packet->data->read<uint32>();
		unk8 = packet->data->read<uint32>();
		unk9 = packet->data->read<uint32>();
		unk10 = packet->data->read<uint32>();
		unk11 = packet->data->read<uint32>();
		unk12 = packet->data->read<uint32>();
		target = packet->data->read<uint32>();
		unk13 = packet->data->read<uint32>();
		unk14 = packet->data->read<uint32>();
		unk15 = packet->data->read<uint32>();
		unk16 = packet->data->read<uint32>();
		unk17 = packet->data->read<uint32>();
	}
	catch(char* msg)
	{
		Log.Error("Crash Error at Function HitEnemy @ CobatHandler.cpp\nMsg: %s \n", msg);
	}
	if(target>0)
	{

		if(checkEnemyInRange(client) && curCombat.fraction > 0)
		{
			PacketBuffer aBuffer(500);
			aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
			aBuffer.write<uint32>(0x00000097);
			aBuffer.write<uint32>(0x642cd3d6);
			aBuffer.write<uint32>(0x0000c350);
			aBuffer.write<uint32>(client->nClientInst);
			aBuffer.write<uint16>(0x0004);
			aBuffer.write<uint32>(unk2);
			aBuffer.write<uint32>(unk3);
			aBuffer.write<uint32>(unk4);
			aBuffer.write<uint32>(unk5 + 1);
			aBuffer.write<uint32>(unk6);
			aBuffer.write<uint32>(unk7);
			aBuffer.write<uint32>(unk8);
			aBuffer.write<uint32>(unk9);
			aBuffer.write<uint32>(unk10);
			aBuffer.write<uint32>(unk11);
			aBuffer.write<uint32>(unk12);
			aBuffer.write<uint32>(target);
			aBuffer.write<uint32>(unk13);
			aBuffer.write<uint32>(unk14);
			aBuffer.write<uint32>(unk15);
			aBuffer.write<uint32>(unk16);
			aBuffer.write<uint32>(unk17);
			aBuffer.write<uint32>(0);
			aBuffer.write<uint32>(0);
			aBuffer.write<uint32>(0);
			aBuffer.write<uint32>(0);
			aBuffer.write<uint32>(0);
			aBuffer.write<uint32>(unk17);
			aBuffer.write<uint32>(0x0000c350);
			aBuffer.write<uint32>(target);
			aBuffer.write<uint8>(0);
			aBuffer.write<uint32>(0x00000006);
			aBuffer.write<uint32>(0x000000ca);
			aBuffer.write<uint32>(0x00000001);
			aBuffer.write<uint32>(0x00000001);
			aBuffer.write<uint32>(0x00000960); //hit 24.00
			aBuffer.write<uint32>(0x00000003);
			aBuffer.write<uint32>(0);
			aBuffer.write<uint32>(0);
			aBuffer.write<uint32>(0x3e4f4f3c);
			aBuffer.doItAll(client->clientSocket);

			curCombat.curHealth -= 24;

			uint32 checkHealth = curCombat.curHealth & 0xf0000000;

			if(curCombat.curHealth <= 0 || checkHealth == 0xf0000000)
			{
				client->charInfo.curExp += curCombat.getExp;
				curCombat.combat.inCombat = false;
				curCombat.combat.target = 0;

				increaseExp(client);

				aBuffer = PacketBuffer(500);
				aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
				aBuffer.write<uint32>(0x0000004a);
				aBuffer.write<uint32>(0x642cd3d6);	// to enemy down
				aBuffer.write<uint32>(0x0000c350);
				aBuffer.write<uint32>(client->charInfo.combat.target);
				aBuffer.write<uint16>(0x0004);
				aBuffer.write<uint32>(0x0000001f);
				aBuffer.write<uint32>(0x0000a395);
				aBuffer.write<uint32>(0);
				aBuffer.write<uint32>(0x00000008);
				aBuffer.write<uint32>(0x00000008);
				aBuffer.write<uint32>(0x00006157);
				aBuffer.write<uint32>(0);
				aBuffer.write<uint32>(0);
				aBuffer.write<uint32>(0);
				aBuffer.write<uint32>(0);
				aBuffer.write<uint32>(0);
				aBuffer.write<uint32>(0);
				aBuffer.write<uint32>(0);
				aBuffer.write<uint32>(0x000000dc);
				aBuffer.write<uint32>(0x3e4f4f3c);
				aBuffer.doItAll(client->clientSocket);

				if(client->charInfo.curExp >= client->charInfo.maxStats.exp)
				{
					client->charInfo.level++;
					increaseLevel(client);
				}
			}
		}
		else
		{
			PacketBuffer aBuffer(500);
			aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
			aBuffer.write<uint32>(0x00000097);
			aBuffer.write<uint32>(0x642cd3d6);
			aBuffer.write<uint32>(0x0000c350);
			aBuffer.write<uint32>(client->nClientInst);
			aBuffer.write<uint16>(0x0004);
			aBuffer.write<uint32>(unk2);
			aBuffer.write<uint32>(unk3);
			aBuffer.write<uint32>(unk4);
			aBuffer.write<uint32>(unk5 + 1);
			aBuffer.write<uint32>(unk6);
			aBuffer.write<uint32>(unk7);
			aBuffer.write<uint32>(unk8);
			aBuffer.write<uint32>(unk9);
			aBuffer.write<uint32>(unk10);
			aBuffer.write<uint32>(unk11);
			aBuffer.write<uint32>(unk12);
			aBuffer.write<uint32>(target);
			aBuffer.write<uint32>(unk13);
			aBuffer.write<uint32>(unk14);
			aBuffer.write<uint32>(unk15);
			aBuffer.write<uint32>(unk16);
			aBuffer.write<uint32>(unk17);
			aBuffer.write<uint32>(0);
			aBuffer.write<uint32>(0);
			aBuffer.write<uint32>(0);
			aBuffer.write<uint32>(0);
			aBuffer.write<uint32>(0);
			aBuffer.write<uint32>(unk17);
			aBuffer.write<uint32>(0x0000c350);
			aBuffer.write<uint32>(target);
			aBuffer.write<uint8>(0);
			aBuffer.write<uint32>(0x00000006);
			aBuffer.write<uint32>(0x000000ca);
			aBuffer.write<uint32>(0x00000001);
			aBuffer.write<uint32>(0x00000001);
			aBuffer.write<uint32>(0x00000000); //hit
			aBuffer.write<uint32>(0x00000000);
			aBuffer.write<uint32>(0);
			aBuffer.write<uint32>(0);
			aBuffer.write<uint32>(0x3e4f4f3c);
			aBuffer.doItAll(client->clientSocket);
		}
	}
	else
	{
		PacketBuffer aBuffer(500);
		aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
		aBuffer.write<uint32>(0x00000097);
		aBuffer.write<uint32>(0x642cd3d6);
		aBuffer.write<uint32>(0x0000c350);
		aBuffer.write<uint32>(client->nClientInst);
		aBuffer.write<uint16>(0x0004);
		aBuffer.write<uint32>(unk2);
		aBuffer.write<uint32>(unk3);
		aBuffer.write<uint32>(unk4);
		aBuffer.write<uint32>(unk5 + 1);
		aBuffer.write<uint32>(unk6);
		aBuffer.write<uint32>(unk7);
		aBuffer.write<uint32>(unk8);
		aBuffer.write<uint32>(unk9);
		aBuffer.write<uint32>(unk10);
		aBuffer.write<uint32>(unk11);
		aBuffer.write<uint32>(unk12);
		aBuffer.write<uint32>(0);
		aBuffer.write<uint32>(unk13);
		aBuffer.write<uint32>(unk14);
		aBuffer.write<uint32>(unk15);
		aBuffer.write<uint32>(unk16);
		aBuffer.write<uint32>(unk17);
		aBuffer.write<uint32>(0);
		aBuffer.write<uint32>(0);
		aBuffer.write<uint32>(0);
		aBuffer.write<uint32>(0);
		aBuffer.write<uint32>(0);
			aBuffer.write<uint32>(unk17);
			aBuffer.write<uint32>(0x0000c350);
			aBuffer.write<uint32>(target);
			aBuffer.write<uint8>(0);
			aBuffer.write<uint32>(0x00000006);
			aBuffer.write<uint32>(0x000000ca);
			aBuffer.write<uint32>(0x00000001);
			aBuffer.write<uint32>(0x00000001);
			aBuffer.write<uint32>(0x00000000); //hit
			aBuffer.write<uint32>(0x00000000);
			aBuffer.write<uint32>(0);
			aBuffer.write<uint32>(0);
		aBuffer.write<uint32>(0x3e4f4f3c);
		aBuffer.doItAll(client->clientSocket);
	}

	updateNpcData(client, curCombat);
}

void WorldServer::increaseExp(GameClient* client)
{
	PacketBuffer aBuffer(500);
	aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
	aBuffer.write<uint32>(0x00000019);
	aBuffer.write<uint32>(0xf98e10b3);
	aBuffer.write<uint32>(0x0000c350);
	aBuffer.write<uint32>(client->nClientInst);
	aBuffer.write<uint8>(0x01);
	aBuffer.write<uint32>(0x00000034);
	aBuffer.write<uint32>(client->charInfo.curExp); //the complete exp from user.
	aBuffer.write<uint32>(0x3e4f4f3c);
	aBuffer.doItAll(client->clientSocket);
}

void WorldServer::increaseLevel(GameClient* client, int lvl)
{

	client->charInfo.level+=lvl;
	//change level
	PacketBuffer aBuffer(500);
	aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
	aBuffer.write<uint32>(0x00000019);
	aBuffer.write<uint32>(0xf98e10b3);
	aBuffer.write<uint32>(0x0000c350);
	aBuffer.write<uint32>(client->nClientInst);
	aBuffer.write<uint8>(0x01);//01
	aBuffer.write<uint32>(0x000003c5);
	aBuffer.write<uint32>(lvl? client->charInfo.level+lvl : client->charInfo.level ); //visual level of char
	aBuffer.write<uint32>(0x3e4f4f3c);
	aBuffer.doItAll(client->clientSocket);

	aBuffer = PacketBuffer(500);
	aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
	aBuffer.write<uint32>(0x0000002d);
	aBuffer.write<uint32>(0x6d314743);
	aBuffer.write<uint32>(0x0000c350);
	aBuffer.write<uint32>(client->nClientInst);
	aBuffer.write<uint8>(0x00);
	aBuffer.write<uint32>(lvl? client->charInfo.level+lvl : client->charInfo.level); //physical level :)
	aBuffer.write<uint32>(client->charInfo.maxStats.exp);
	aBuffer.write<uint32>(client->charInfo.maxStats.exp);
	aBuffer.write<uint32>(0x00000154);
	aBuffer.write<uint32>(((lvl? client->charInfo.level+lvl : client->charInfo.level) - 1));
	aBuffer.write<uint32>(0x00000008);
	aBuffer.write<uint32>(0x00000000);
	aBuffer.write<uint32>(0x3e4f4f3c);
	aBuffer.doItAll(client->clientSocket);
	//Update server stuff
	Database.getMaxStats(client);
	client->charInfo.InitalizeStatupStats(client);
	//update here max hp,stamina,mana stas for client sniff here for the packet 
	//Update stamina
	aBuffer = PacketBuffer(500);
	aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
	aBuffer.write<uint32>(0x0000001d);
	aBuffer.write<uint32>(0x96b8dc59);
	aBuffer.write<uint32>(0x0000c350);
	aBuffer.write<uint32>(client->nClientInst);
	aBuffer.write<uint8>(0x00);
	aBuffer.write<uint32>(0x00000001);
	aBuffer.write<uint32>(0x000001f9);
	aBuffer.write<uint32>(client->charInfo.maxStats.stamina*100);
	aBuffer.write<uint32>(0x3e4f4f3c);
	aBuffer.doItAll(client->clientSocket);
	if(client->charInfo.maxStats.mana>0)
	{
		//mana
		aBuffer = PacketBuffer(500);
		aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
		aBuffer.write<uint32>(0x0000001d);
		aBuffer.write<uint32>(0x96b8dc59);
		aBuffer.write<uint32>(0x0000c350);
		aBuffer.write<uint32>(client->nClientInst);
		aBuffer.write<uint8>(0x00);
		aBuffer.write<uint32>(0x00000001);
		aBuffer.write<uint32>(0x000001fb);
		aBuffer.write<uint32>(client->charInfo.maxStats.mana*100);
		aBuffer.write<uint32>(0x3e4f4f3c);
		aBuffer.doItAll(client->clientSocket);
	}
	//Update Health
	aBuffer = PacketBuffer(500);
	aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
	aBuffer.write<uint32>(0x0000001d);
	aBuffer.write<uint32>(0x96b8dc59);
	aBuffer.write<uint32>(0x0000c350);
	aBuffer.write<uint32>(client->nClientInst);
	aBuffer.write<uint8>(0x00);
	aBuffer.write<uint32>(0x00000001);
	aBuffer.write<uint32>(0x00000001);
	aBuffer.write<uint32>(client->charInfo.maxStats.health*100);
	aBuffer.write<uint32>(0x3e4f4f3c);
	aBuffer.doItAll(client->clientSocket);

	//test attribs remoteformats
	/*	aBuffer = PacketBuffer(1000);
	uint8 attrib1[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0x00, 0x06, 0x01, 0xfb, 0x3c, 0x72, 0x65, 0x6d, 0x6f, 0x74, 0x65, 0x66, 0x6f, 0x72, 0x6d, 0x61, 0x74, 0x20, 0x74, 0x6f, 0x6b, 0x65, 0x6e, 0x3d, 0x22, 0x41, 0x74, 0x74, 0x72, 0x69, 0x62, 0x75, 0x74, 0x65, 0x43, 0x68, 0x61, 0x6e, 0x67, 0x65, 0x64, 0x22, 0x20, 0x63, 0x61, 0x74, 0x65, 0x67, 0x6f, 0x72, 0x79, 0x3d, 0x22, 0x31, 0x30, 0x30, 0x22, 0x20, 0x6b, 0x65, 0x79, 0x3d, 0x22, 0x57, 0x38, 0x4b, 0x66, 0x76, 0x2f, 0x40, 0x6c, 0x32, 0x39, 0x70, 0x24, 0x65, 0x61, 0x30, 0x2e, 0x24, 0x72, 0x3f, 0x2e, 0x22, 0x20, 0x6b, 0x6e, 0x75, 0x62, 0x6f, 0x74, 0x3d, 0x22, 0x30, 0x22, 0x20, 0x20, 0x3e, 0x3c, 0x70, 0x61, 0x72, 0x61, 0x6d, 0x65, 0x74, 0x65, 0x72, 0x20, 0x76, 0x61, 0x6c, 0x75, 0x65, 0x3d, 0x22, 0x36, 0x3b, 0x26, 0x6c, 0x74, 0x3b, 0x72, 0x65, 0x6d, 0x6f, 0x74, 0x65, 0x66, 0x6f, 0x72, 0x6d, 0x61, 0x74, 0x20, 0x69, 0x64, 0x3d, 0x26, 0x71, 0x75, 0x6f, 0x74, 0x3b, 0x38, 0x30, 0x34, 0x26, 0x71, 0x75, 0x6f, 0x74, 0x3b, 0x20, 0x63, 0x61, 0x74, 0x65, 0x67, 0x6f, 0x72, 0x79, 0x3d, 0x26, 0x71, 0x75, 0x6f, 0x74, 0x3b, 0x36, 0x31, 0x35, 0x26, 0x71, 0x75, 0x6f, 0x74, 0x3b, 0x20, 0x6b, 0x65, 0x79, 0x3d, 0x26, 0x71, 0x75, 0x6f, 0x74, 0x3b, 0x3f, 0x6d, 0x33, 0x71, 0x4a, 0x5a, 0x4e, 0x72, 0x54, 0x53, 0x42, 0x6b, 0x79, 0x38, 0x72, 0x70, 0x32, 0x6c, 0x2c, 0x77, 0x26, 0x71, 0x75, 0x6f, 0x74, 0x3b, 0x20, 0x6b, 0x6e, 0x75, 0x62, 0x6f, 0x74, 0x3d, 0x26, 0x71, 0x75, 0x6f, 0x74, 0x3b, 0x30, 0x26, 0x71, 0x75, 0x6f, 0x74, 0x3b, 0x20, 0x20, 0x26, 0x67, 0x74, 0x3b, 0x26, 0x6c, 0x74, 0x3b, 0x2f, 0x72, 0x65, 0x6d, 0x6f, 0x74, 0x65, 0x66, 0x6f, 0x72, 0x6d, 0x61, 0x74, 0x26, 0x67, 0x74, 0x3b, 0x22, 0x20, 0x2f, 0x3e, 0x3c, 0x70, 0x61, 0x72, 0x61, 0x6d, 0x65, 0x74, 0x65, 0x72, 0x20, 0x76, 0x61, 0x6c, 0x75, 0x65, 0x3d, 0x22, 0x36, 0x3b, 0x26, 0x6c, 0x74, 0x3b, 0x72, 0x65, 0x6d, 0x6f, 0x74, 0x65, 0x66, 0x6f, 0x72, 0x6d, 0x61, 0x74, 0x20, 0x74, 0x6f, 0x6b, 0x65, 0x6e, 0x3d, 0x26, 0x71, 0x75, 0x6f, 0x74, 0x3b, 0x49, 0x6e, 0x63, 0x72, 0x65, 0x61, 0x73, 0x65, 0x64, 0x26, 0x71, 0x75, 0x6f, 0x74, 0x3b, 0x20, 0x63, 0x61, 0x74, 0x65, 0x67, 0x6f, 0x72, 0x79, 0x3d, 0x26, 0x71, 0x75, 0x6f, 0x74, 0x3b, 0x31, 0x30, 0x30, 0x26, 0x71, 0x75, 0x6f, 0x74, 0x3b, 0x20, 0x6b, 0x65, 0x79, 0x3d, 0x26, 0x71, 0x75, 0x6f, 0x74, 0x3b, 0x61, 0x6b, 0x66, 0x4c, 0x64, 0x4e, 0x26, 0x61, 0x6d, 0x70, 0x3b, 0x23, 0x33, 0x39, 0x3b, 0x60, 0x30, 0x68, 0x5e, 0x2f, 0x65, 0x61, 0x78, 0x30, 0x47, 0x49, 0x3f, 0x4b, 0x26, 0x71, 0x75, 0x6f, 0x74, 0x3b, 0x20, 0x6b, 0x6e, 0x75, 0x62, 0x6f, 0x74, 0x3d, 0x26, 0x71, 0x75, 0x6f, 0x74, 0x3b, 0x30, 0x26, 0x71, 0x75, 0x6f, 0x74, 0x3b, 0x20, 0x20, 0x26, 0x67, 0x74, 0x3b, 0x26, 0x6c, 0x74, 0x3b, 0x2f, 0x72, 0x65, 0x6d, 0x6f, 0x74, 0x65, 0x66, 0x6f, 0x72, 0x6d, 0x61, 0x74, 0x26, 0x67, 0x74, 0x3b, 0x22, 0x20, 0x2f, 0x3e, 0x3c, 0x70, 0x61, 0x72, 0x61, 0x6d, 0x65, 0x74, 0x65, 0x72, 0x20, 0x76, 0x61, 0x6c, 0x75, 0x65, 0x3d, 0x22, 0x31, 0x3b, 0x33, 0x31, 0x38, 0x34, 0x36, 0x36, 0x33, 0x31, 0x31, 0x31, 0x31, 0x39, 0x33, 0x38, 0x35, 0x33, 0x39, 0x35, 0x34, 0x22, 0x20, 0x2f, 0x3e, 0x3c, 0x2f, 0x72, 0x65, 0x6d, 0x6f, 0x74, 0x65, 0x66, 0x6f, 0x72, 0x6d, 0x61, 0x74, 0x3e, 0x00, 0x00, 0x00, 0x00, 0x3e, 0x4f, 0x4f, 0x3c};
	aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
	aBuffer.write<uint32>(0x0000022e);
	aBuffer.write<uint32>(0x8d5a8b6b);
	aBuffer.write<uint32>(0x0000c350);
	aBuffer.write<uint32>(client->nClientInst);
	aBuffer.write<uint8>(0x00);
	aBuffer.writeArray(attrib1,sizeof(attrib1));
	aBuffer.doItAll(client->clientSocket);*/		
}

bool WorldServer::checkEnemyInRange(GameClient* client)
{
	NPC combat_npc = getNpcData(client, client->charInfo.combat.target);
	if(combat_npc.position.x >= (client->charInfo.position.x - 0x00010000) && combat_npc.position.x <= (client->charInfo.position.x + 0x00010000))
	{
		if(combat_npc.position.y >= (client->charInfo.position.y - 0x00010000) && combat_npc.position.y <= (client->charInfo.position.y + 0x00010000))
		{
			if(combat_npc.position.z >= (client->charInfo.position.z - 0x00010000) && combat_npc.position.z <= (client->charInfo.position.z + 0x00010000))
			{
				return true;
			}
			else
			{
				//Don't work correctly
				//enemyRunToPlayer(client);
				return false;
			}
		}
		else
		{
			//Don't work correctly
			//enemyRunToPlayer(client);
			return false;
		}
	}
	else
	{
		//Don't work correctly
		//enemyRunToPlayer(client);
		return false;
	}
}

void WorldServer::enemyRunToPlayer(GameClient* client)
{
	/*
	DON'T WORK CORRECTLY -> DISABLED

	first need to find how to create the speed-value.
	*/

	uint32 speed = 0x41518ebd; //1095863997 ~ 3 seconds to player
	//0x41eb2856 ~ 5 seconds
	//speed = 0x42518ebd; // 1112641213   ~ 8 seconds to player
	//0x431e5b88 ~24 seconds
	/*
	3 seconds = 0x41518ebd
	0x999999 = 10066329 // + 2seconds   // per second 5033164
	5 seconds = 0x41eb2856
	0x666667 =  6710887 // + 3seconds   // per second 2236962
	8 seconds = 0x42518ebd  // 1112641213
	0xCCCCCB = 13421771 // + 16 seconds // per second 838860
	24 seconds = 0x431e5b88 // 1126062984
	//*/
	//speed = 0x425E5B89; //it is ~ 9 seconds // 1113480073

	//take 8 seconds as speed
	speed = 0x42518ebd;

	NPC combat_npc = getNpcData(client, client->charInfo.combat.target);
	NPCMove CalcMove;
	CalcMove.range = combat_npc.position;

	if(!combat_npc.move.isMoving)
	{
#ifdef WINDOWS
		SYSTEMTIME now;
		GetSystemTime(&now);
		uint32 curTime = (((now.wSecond / 60)*100)* 1000) + now.wMilliseconds;
#else
		timeval now;
		gettimeofday(&now, 0);
		uint32 curTime = (((now.tv_sec / 60)*100)* 1000) + now.tv_usec;
#endif

		combat_npc.move.milliseconds = curTime;
		combat_npc.move.range = setRange(client, combat_npc);
		Log.Notice("Range ( 0x%08x - 0x%08x - 0x%08x)\nSpeed %u - 0x%08x\n", combat_npc.move.range.x, combat_npc.move.range.y, combat_npc.move.range.z,
			speed, speed);
		ldouble test = combat_npc.position.distance(client->charInfo.position);
		Log.Notice("Way: %f\n", test);
		combat_npc.move.isMoving = true;
	}
	else
	{
		//todo calculate way by time
		CalcMove.range = calculateWay(client, combat_npc);
		if(CalcMove.range.x == client->charInfo.position.x && CalcMove.range.y == client->charInfo.position.y && CalcMove.range.z == client->charInfo.position.z)
		{
			combat_npc.move.isMoving = false;
			combat_npc.position = CalcMove.range;
		}
	}

	PacketBuffer aBuffer(5000);
	aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
	aBuffer.write<uint32>(0x0000005c);
	aBuffer.write<uint32>(0x96c46740);
	aBuffer.write<uint32>(0x0000c350);
	aBuffer.write<uint32>(client->charInfo.combat.target);
	aBuffer.write<uint16>(0);
	//aBuffer.write<uint32>(combat_npc.position.x);
	//aBuffer.write<uint32>(combat_npc.position.y);
	//aBuffer.write<uint32>(combat_npc.position.z);
	aBuffer.write<uint32>(CalcMove.range.x);
	aBuffer.write<uint32>(CalcMove.range.y);
	aBuffer.write<uint32>(CalcMove.range.z);
	aBuffer.write<uint16>(0x0401);
	aBuffer.write<uint32>(0x00020101);
	aBuffer.write<uint8>(0x00);
	aBuffer.write<uint32>(0x00000002);
	//aBuffer.write<uint32>(combat_npc.position.x);
	//aBuffer.write<uint32>(combat_npc.position.y);
	//aBuffer.write<uint32>(combat_npc.position.z);
	aBuffer.write<uint32>(CalcMove.range.x);
	aBuffer.write<uint32>(CalcMove.range.y);
	aBuffer.write<uint32>(CalcMove.range.z);
	//aBuffer.write<uint32>(getCoordToPlayer(client->charInfo.position.x, combat_npc.position.x));
	//aBuffer.write<uint32>(getCoordToPlayer(client->charInfo.position.y, combat_npc.position.y));
	//aBuffer.write<uint32>(getCoordToPlayer(client->charInfo.position.z, combat_npc.position.z));
	aBuffer.write<uint32>(getCoordToPlayer(client->charInfo.position.x, CalcMove.range.x));
	aBuffer.write<uint32>(getCoordToPlayer(client->charInfo.position.y, CalcMove.range.y));
	aBuffer.write<uint32>(getCoordToPlayer(client->charInfo.position.z, CalcMove.range.z));
	aBuffer.write<uint8>(0x00);
	aBuffer.write<uint32>(speed); //i think that is something with speed
	//aBuffer.write<uint32>(0x40d08490);
	aBuffer.write<uint32>(0);
	aBuffer.write<uint32>(0);
	//aBuffer.write<uint32>(combat_npc.position.x);
	//aBuffer.write<uint32>(combat_npc.position.y);
	//aBuffer.write<uint32>(combat_npc.position.z);
	aBuffer.write<uint32>(CalcMove.range.x);
	aBuffer.write<uint32>(CalcMove.range.y);
	aBuffer.write<uint32>(CalcMove.range.z);
	aBuffer.write<uint16>(0x0001);
	aBuffer.write<uint32>(0x3e4f4f3c);
	aBuffer.doItAll(client->clientSocket);

	updateNpcData(client, combat_npc);
}

uint32 WorldServer::getCoordToPlayer(uint32 player, uint32 npc)
{
	if(player > npc)
	{
		return (player - 0x00010000);
	}
	else if(player < npc)
	{
		return (player + 0x00010000);
	}
	else
	{
		return player;
	}
}

NPC WorldServer::getNpcData(GameClient* client, uint32 npcId)
{
	NPC dummy;
	for(uint32 i = 0; i < client->datastoreNpcs.size(); i++)
	{
		if(client->datastoreNpcs[i].npcId == npcId)
		{
			return client->datastoreNpcs[i];
		}
	}
	return dummy;
}

void WorldServer::updateNpcData(GameClient* client, NPC curNpc)
{
	for(uint32 i = 0; i < client->datastoreNpcs.size(); i++)
	{
		if(client->datastoreNpcs[i].npcId == curNpc.npcId)
		{
			client->datastoreNpcs[i] = curNpc;
		}
	}
}

Vector3D WorldServer::setRange(GameClient* client, NPC curNpc)
{
	uint32 x, y, z;
	if(client->charInfo.position.x > curNpc.position.x)
	{
		x = client->charInfo.position.x - curNpc.position.x;
	}
	else
	{
		x = curNpc.position.x - client->charInfo.position.x;
	}

	if(client->charInfo.position.y > curNpc.position.y)
	{
		y = client->charInfo.position.y - curNpc.position.y;
	}
	else
	{
		y = curNpc.position.y - client->charInfo.position.y;
	}

	if(client->charInfo.position.z > curNpc.position.z)
	{
		z = client->charInfo.position.z - curNpc.position.z;
	}
	else
	{
		z = curNpc.position.z - client->charInfo.position.z;
	}

	return Vector3D(x, y, z);
}

Vector3D WorldServer::calculateWay(GameClient* client, NPC curNpc)
{
#ifdef WINDOWS
	SYSTEMTIME now;
	GetSystemTime(&now);
	uint32 curTime = (((now.wSecond / 60)*100)* 1000) + now.wMilliseconds;
#else
	timeval now;
	gettimeofday(&now, 0);
	uint32 curTime = (((now.tv_sec / 60)*100)* 1000) + now.tv_usec;
#endif

	int32 dif = curTime - curNpc.move.milliseconds;
	Log.Notice("Current time: %i\nStart time: %i\nDifferenz: %i\n", curTime, curNpc.move.milliseconds, dif);
	int32 x, y, z;
	//8 = speed in seconds
	if( dif < (8 * 1000))
	{
		NPCMove CalcMove;
		CalcMove.range = getCurrentPosition(curNpc.move.range, dif, 8);
		if(client->charInfo.position.x > curNpc.position.x)
		{
			x = curNpc.position.x + CalcMove.range.x;
			if(x > client->charInfo.position.x)
			{
				x = client->charInfo.position.x;
			}
		}
		else
		{
			x = curNpc.position.x - CalcMove.range.x;
			if(x < client->charInfo.position.x)
			{
				x = client->charInfo.position.x;
			}
		}
		if(client->charInfo.position.y > curNpc.position.y)
		{
			y = curNpc.position.y + CalcMove.range.y;
			if(y > client->charInfo.position.y)
			{
				y = client->charInfo.position.y;
			}
		}
		else
		{
			y = curNpc.position.y - CalcMove.range.y;
			if(y < client->charInfo.position.y)
			{
				y = client->charInfo.position.y;
			}
		}
		if(client->charInfo.position.z > curNpc.position.z)
		{
			z = curNpc.position.z + CalcMove.range.z;
			if(z > client->charInfo.position.z)
			{
				z = client->charInfo.position.z;
			}
		}
		else
		{
			z = curNpc.position.z - CalcMove.range.z;
			if(z < client->charInfo.position.z)
			{
				z = client->charInfo.position.z;
			}
		}
	}
	else
	{
		x = client->charInfo.position.x;
		y = client->charInfo.position.y;
		z = client->charInfo.position.z;
	}

	Log.Notice("Calculating Vector: (0x%08x - 0x%08x - 0x%08x)\n", x, y, z);
	return Vector3D(x, y, z);
}

Vector3D WorldServer::getCurrentPosition(Vector3D range, uint32 diff, uint32 speed)
{
	uint32 x = (range.x / (speed * 100)) * diff;
	uint32 y = (range.y / (speed * 100)) * diff;
	uint32 z = (range.z / (speed * 100)) * diff;

	return Vector3D(x, y, z);
}

void WorldServer::checkInCombat(GameClient* client, double timeDiff)
{
	for(uint32 i = 0; i < client->datastoreNpcs.size(); i++)
	{
		if(client->datastoreNpcs[i].combat.target == client->nClientInst)
		{
			if(checkInRange(client->charInfo.position, client->datastoreNpcs[i].position))
			{
				/*
				TODO:
				- get attacktyp from npc
				- get attackspeed from npc
				- check time if attack is possible
				- get Hit value from npc
				- attack player
				*/
				//Log.Notice("TimeDiff @ combat: %f\n", timeDiff);
				if(timeDiff >= 2.00)
				{
					PacketBuffer aBuffer(5000);
					aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
					aBuffer.write<uint32>(0x00000093);
					aBuffer.write<uint32>(0x642cd3d6);
					aBuffer.write<uint32>(0x0000c350);
					aBuffer.write<uint32>(client->datastoreNpcs[i].npcId);
					aBuffer.write<uint16>(0x0004);
					aBuffer.write<uint32>(0x0000000f);
					aBuffer.write<uint32>(0x0000ab21);
					aBuffer.write<uint32>(0x00000000);
					aBuffer.write<uint32>(0x00000008);
					aBuffer.write<uint32>(0x00000018);
					aBuffer.write<uint32>(0x000070ad);
					aBuffer.write<uint32>(0x00000000);
					aBuffer.write<uint32>(0x00000000);
					aBuffer.write<uint32>(0x00000000);
					aBuffer.write<uint32>(0x00000000);
					aBuffer.write<uint32>(0x0000c350);
					aBuffer.write<uint32>(client->nClientInst);
					aBuffer.write<uint32>(0x0000003c);
					aBuffer.write<uint32>(0x00000034);
					aBuffer.write<uint32>(0x00000000);
					aBuffer.write<uint32>(0x00000000);
					aBuffer.write<uint32>(0x00000001);
					aBuffer.write<uint32>(0x00000000);
					aBuffer.write<uint32>(0x00000000);
					aBuffer.write<uint32>(0x00000000);
					aBuffer.write<uint32>(0x00000000);
					aBuffer.write<uint32>(0x00000000);
					aBuffer.write<uint32>(0x00000001);
					aBuffer.write<uint32>(0x0000c350);
					aBuffer.write<uint32>(client->nClientInst);
					aBuffer.write<uint8>(0);
					aBuffer.write<uint32>(0x00000006);
					aBuffer.write<uint32>(0x000000c9);
					aBuffer.write<uint32>(0x00000000); //
					aBuffer.write<uint32>(0x00000002); //attack speed?
					aBuffer.write<uint32>(0x00001388); //hit 1.00 /50.00
					aBuffer.write<uint32>(0x00000001);
					aBuffer.write<uint32>(0);
					aBuffer.write<uint32>(0x3e4f4f3c);
					aBuffer.doItAll(client->clientSocket);
					client->charInfo.hp -=50; //testing healthregen
				}
			}
		}
	}
}

bool WorldServer::checkInRange(Vector3D target, Vector3D npc)
{
	return true;

	if(target.distance(npc) < 100000)
		return true;

	return false;
}