/*
Project Faolan a Simple and Free Server Emulator for Age of Conan.
Copyright (C) 2009, 2010 The Project Faolan Team

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef WORLDSERVER_H
#define WORLDSERVER_H

#include "../Common/Common.h"
#include "../Common/Settings.h"
#include "../Common/MysqlDatabase.h"
#include "../Common/Functions.h"
#include "../Common/PacketBuffer.h"
#include "../Common/Packet.h"
#include "../Common/Networking.h"
#include "../Common/Structs.h"
#include "../Common/Logger.h"
#include "../Common/Timer.h"

#ifdef WINDOWS
#include <Windows.h>
#else
#include <sys/time.h>
#endif

using namespace std;

#define SPRINT_DECREASE 55

namespace WorldServer
{
	void LoadNearChars(GameClient* client, vector<GameClient*>* clientList);
	bool checkAlreadySpawned(GameClient* client, uint32 characterId);
	//CombatHandler
	void HitWithSpell(GameClient* client, Packet* packet);
	void HitEnemy(GameClient* client, Packet* packet);
	void increaseExp(GameClient* client);
	void increaseLevel(GameClient* client, int lvl = 0);
	bool checkEnemyInRange(GameClient* client);
	void enemyRunToPlayer(GameClient* client);
	uint32 getCoordToPlayer(uint32 player, uint32 npc);

	NPC getNpcData(GameClient* client, uint32 npcId);
	void updateNpcData(GameClient* client, NPC curNpc);
	Vector3D setRange(GameClient* client, NPC curNpc);
	Vector3D calculateWay(GameClient* client, NPC curNpc);
	Vector3D getCurrentPosition(Vector3D range, uint32 diff, uint32 speed);

	void checkInCombat(GameClient* client, double timeDiff);
	bool checkInRange(Vector3D target, Vector3D npc);

	void LoadNearNPCs(GameClient* client);
	bool checkInRange(Vector3D charPos, Vector3D npcPos);
	bool checkAlreadySpawned(vector<uint32>* spawned, uint32 npcId);
	uint8 GetDigitValue(int8 digit);
	void eraseAllNpcs(GameClient* client);

	void GameAgentHandler(Packet* packet, GameClient* client, vector<GameClient*>* clientList);
	void GameCharAgentHandler(Packet* packet, GameClient* client);
	void GameCharAgentProjectHandler(Packet* packet, GameClient* client);

	void HandleCommand(GameClient* client, string command, vector<GameClient*>* clientList);
	void addCharLevel(string level,GameClient *Client);
	void addItem(string itemname, GameClient* client);
	void addMoney(uint32 cash, GameClient* client);
	void teleportChar(string zone, GameClient* client, vector<GameClient*>* clientList);

	void HandleClient(void* socket);

	//AbilityHandler
	void checkAbility(GameClient* client);
	void addAbility(GameClient* client, uint32 abilityId, uint32 level);
	void addSpell(GameClient* client, uint32 SpellId);
}
#endif
