/*
Project Faolan a Simple and Free Server Emulator for Age of Conan.
Copyright (C) 2009, 2010 The Project Faolan Team

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "WorldServer.h"

void WorldServer::GameCharAgentHandler(Packet* packet, GameClient* client)
{
	switch(packet->opcode)
	{
	case 0x01: // RequestAggroStatus
		{
			uint32 unk1 = packet->data->read<uint32>(); // 00 00 C3 50 
			uint32 clientInst = packet->data->read<uint32>(); // 11 01 89 CA 
			uint32 unk3 = packet->data->read<uint32>(); // 00 00 C3 50 
			uint32 unk4 = packet->data->read<uint32>(); // 00 06 A1 27

			PacketBuffer aBuffer(500);
			aBuffer.writeHeader("GameCharAgent", "GameCharInterface", gameUnknown1, 0, client->nClientInst, 0, 0x01); // UpdateAggroStatus
			aBuffer.write<uint32>(0x0000C350); // = 50000 - WTF is this? (It is all over the place) 
			aBuffer.write<uint32>(0x0006A12A); // npc ID?
			aBuffer.write<uint32>(0x00000002); // aggro value?
			aBuffer.doItAll(client->clientSocket);

			break;
		}

	case 0x4F:
		{			
			uint32 attID = packet->data->read<uint32>(); // i think this is the spellID... 
			// 0x00000103 = switch weapon
			// 0x000004e2 = toggle combat
			// 0x000004e4 = crouch

			switch(attID)
			{
			default:
				{
					NPC curCombat = getNpcData(client, client->charInfo.combat.target);

					if(curCombat.fraction > 0)
					{
						//client->charInfo.Combat.sendAt4B=false;
						//Log.Notice("ATT TARGET 0x%08x\n", client->charInfo.combat.target);

						PacketBuffer aBuffer(500);
						if(client->nClientInst != curCombat.combat.target)
						{
							curCombat.combat.target = client->nClientInst;

							aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
							aBuffer.write<uint32>(0x0000001d);
							aBuffer.write<uint32>(0xe501139d); //sets symbol over head (in combat)
							aBuffer.write<uint32>(0x0000c350);
							aBuffer.write<uint32>(client->nClientInst);
							aBuffer.write<uint8>(0x00);
							aBuffer.write<uint32>(0x0000c350);
							aBuffer.write<uint32>(client->charInfo.combat.target);
							aBuffer.write<uint32>(0x00000001);
							aBuffer.write<uint32>(0x3e4f4f3c);
							aBuffer.doItAll(client->clientSocket);

							updateNpcData(client, curCombat);
						}

						//Don't work correctly
						//enemyRunToPlayer(client);
					}
					break;
				}
			}

			break;
		}

	case 0x54:
		{
			uint32 data = packet->data->read<uint32>();
			uint32 clientInst = packet->data->read<uint32>();
			uint8 data1 = packet->data->read<uint32>();

			if(data1 == 0x01)
			{
				if(client->charInfo.map == 4000)
				{
					//PACKET 390
					PacketBuffer aBuffer(500);
					aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
					aBuffer.write<uint32>(0x0000001d);
					aBuffer.write<uint32>(0x96b8dc59);
					aBuffer.write<uint32>(0x0000c350);
					aBuffer.write<uint32>(client->nClientInst);
					aBuffer.write<uint8>(0x00);
					aBuffer.write<uint32>(0x00000001);
					aBuffer.write<uint32>(0x000000ba);
					aBuffer.write<uint32>(0);
					aBuffer.write<uint32>(0x3e4f4f3c);
					aBuffer.doItAll(client->clientSocket);
				}
			}

			if(data1 == 0x00)
			{
				if(client->charInfo.map == 4000)
				{
					Log.Debug("Send char_creation camera data\n");
					
					uint8 pack1[] = {
						0x00, 0x00, 0x00, 0x2d, 0x96, 0xb8, 0xdc, 0x59, 0x00, 0x00, 0xc3, 0x50, 0x00, 0x00, 0x2d, 0xd4, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x1b, 0x00, 0x00, 0x18, 0x9c, 0x00, 0x00, 0x01, 0xf8, 0x00, 0x00, 0x18, 0x9c, 0x00, 0x00, 0x01, 0xfa, 0x00, 0x00, 0x18, 0x9c, 0x3e, 0x4f, 0x4f, 0x3c
					};
					PacketBuffer aBuffer(500);
					aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
					aBuffer.writeArray(pack1, sizeof(pack1));
					aBuffer.doItAll(client->clientSocket);

					uint8 pack2[] = {
						0x00, 0x00, 0x00, 0x2d, 0x96, 0xb8, 0xdc, 0x59, 0x00, 0x00, 0xc3, 0x50, 0x00, 0x00, 0x2d, 0xd5, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x1b, 0x00, 0x00, 0x18, 0x9c, 0x00, 0x00, 0x01, 0xf8, 0x00, 0x00, 0x18, 0x9c, 0x00, 0x00, 0x01, 0xfa, 0x00, 0x00, 0x18, 0x9c, 0x3e, 0x4f, 0x4f, 0x3c
					};
					aBuffer = PacketBuffer(500);
					aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
					aBuffer.writeArray(pack2, sizeof(pack2));
					aBuffer.doItAll(client->clientSocket);

					uint8 pack3[] = {
						0x00, 0x00, 0x00, 0x4a, 0x64, 0x2c, 0xd3, 0xd6, 0x00, 0x00, 0xc3, 0x50, 0x00, 0x00, 0x2d, 0xd6, 0x00, 0x04, 0x00, 0x00, 0x00, 0x05, 0x00, 0x01, 0x4f, 0x53, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x0d, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3e, 0x4f, 0x4f, 0x3c
					};
					aBuffer = PacketBuffer(500);
					aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
					aBuffer.writeArray(pack3, sizeof(pack3));
					aBuffer.doItAll(client->clientSocket);

					uint8 pack4[] = {
						0x00, 0x00, 0x00, 0x2d, 0x96, 0xb8, 0xdc, 0x59, 0x00, 0x00, 0xc3, 0x50, 0x00, 0x00, 0x2d, 0xd6, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x1b, 0x00, 0x00, 0x18, 0x9c, 0x00, 0x00, 0x01, 0xf8, 0x00, 0x00, 0x18, 0x9c, 0x00, 0x00, 0x01, 0xfa, 0x00, 0x00, 0x18, 0x9c, 0x3e, 0x4f, 0x4f, 0x3c
					};
					aBuffer = PacketBuffer(500);
					aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
					aBuffer.writeArray(pack4, sizeof(pack4));
					aBuffer.doItAll(client->clientSocket);

					uint8 pack5[] = {
						0x00, 0x00, 0x00, 0x4a, 0x64, 0x2c, 0xd3, 0xd6, 0x00, 0x00, 0xc3, 0x50, 0x00, 0x00, 0x2d, 0xd7, 0x00, 0x04, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0xa1, 0xc5, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3e, 0x4f, 0x4f, 0x3c
					};
					aBuffer = PacketBuffer(500);
					aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
					aBuffer.writeArray(pack5, sizeof(pack5));
					aBuffer.doItAll(client->clientSocket);

					uint8 pack6[] = {
						0x00, 0x00, 0x00, 0x2d, 0x96, 0xb8, 0xdc, 0x59, 0x00, 0x00, 0xc3, 0x50, 0x00, 0x00, 0x2d, 0xd7, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x1b, 0x00, 0x00, 0x18, 0x9c, 0x00, 0x00, 0x01, 0xf8, 0x00, 0x00, 0x18, 0x9c, 0x00, 0x00, 0x01, 0xfa, 0x00, 0x00, 0x18, 0x9c, 0x3e, 0x4f, 0x4f, 0x3c
					};
					aBuffer = PacketBuffer(500);
					aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
					aBuffer.writeArray(pack6, sizeof(pack6));
					aBuffer.doItAll(client->clientSocket);

					uint8 pack7[] = {
						0x00, 0x00, 0x00, 0x4a, 0x64, 0x2c, 0xd3, 0xd6, 0x00, 0x00, 0xc3, 0x50, 0x00, 0x00, 0x2d, 0xd8, 0x00, 0x04, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0xa1, 0xc5, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3e, 0x4f, 0x4f, 0x3c
					};
					aBuffer = PacketBuffer(500);
					aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
					aBuffer.writeArray(pack7, sizeof(pack7));
					aBuffer.doItAll(client->clientSocket);

					uint8 pack8[] = {
						0x00, 0x00, 0x00, 0x2d, 0x96, 0xb8, 0xdc, 0x59, 0x00, 0x00, 0xc3, 0x50, 0x00, 0x00, 0x2d, 0xd8, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x1b, 0x00, 0x00, 0x18, 0x9c, 0x00, 0x00, 0x01, 0xf8, 0x00, 0x00, 0x18, 0x9c, 0x00, 0x00, 0x01, 0xfa, 0x00, 0x00, 0x18, 0x9c, 0x3e, 0x4f, 0x4f, 0x3c
					};
					aBuffer = PacketBuffer(500);
					aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
					aBuffer.writeArray(pack8, sizeof(pack8));
					aBuffer.doItAll(client->clientSocket);

					uint8 pack9[] = {
						0x00, 
						0x00, 0x00, 0x00, 0x06,

						0x00, 0x00, 0x00, 0x1b, //Health
						0x00, 0x00, 0x1f, 0x40, 

						0x00, 0x00, 0x00, 0xba, 
						0x00, 0x00, 0x00, 0x00, 

						0x00, 0x00, 0x01, 0xff, 
						0x00, 0x00, 0x00, 0x00, 

						0x00, 0x00, 0x02, 0x00, 
						0x00, 0x00, 0x00, 0x4a, 

						0x00, 0x00, 0x02, 0x01, 
						0x00, 0x00, 0x00, 0x00, 

						0x00, 0x00, 0x02, 0x5f, 
						0x59, 0x47, 0xc8, 0x29, 

						0x3e, 0x4f, 0x4f, 0x3c
					};
					aBuffer = PacketBuffer(500);
					aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00);
					aBuffer.write<uint32>(0x00000045);
					aBuffer.write<uint32>(0x96b8dc59);
					aBuffer.write<uint32>(0x0000c350);
					aBuffer.write<uint32>(client->nClientInst);
					aBuffer.writeArray(pack9, sizeof(pack9));
					aBuffer.doItAll(client->clientSocket);
					//*/
				}
			}
			//

			break;
		}

	case 0x7b: //Ping
		{
			uint32 i_nSequence = packet->data->read<uint32>();
			uint32 lastdata = packet->data->read<uint32>();

			time_t nServerTime;
			time(&nServerTime);

			PacketBuffer aBuffer(500);
			aBuffer.writeHeader("GameCharAgent", "GameCharInterface", gameUnknown1, 0, client->nClientInst, 0, 0x73); // Pong
			aBuffer.write<uint32>(i_nSequence); // i_nSequence
			aBuffer.write<uint32>(lastdata); // lastdata
			aBuffer.write<uint32>(nServerTime); // nServerTime
			aBuffer.doItAll(client->clientSocket);

			break;
		}

	case 0x77:
		{
			uint32 data = packet->data->read<uint32>(); // This is some sort of counter

			time_t nServerTime;
			time(&nServerTime);

			PacketBuffer aBuffer(500);
			aBuffer.writeHeader("GameCharAgent", "GameCharInterface", gameUnknown1, 0, client->nClientInst, 0, 0x6b);
			aBuffer.write<uint32>(data);
			aBuffer.write<uint32>(0x00000059);	// ???
			aBuffer.write<uint32>(nServerTime);
			aBuffer.doItAll(client->clientSocket);

			//now tests

			break;
		}

	case 0x1D: //UpdateQuestMarkerNPC
		{
			uint32 data = packet->data->read<uint32>(); // 00 00 c3 50
			uint32 data1 = packet->data->read<uint32>(); 
			uint32 data2 = packet->data->read<uint32>(); // 00 00 c3 50
			uint32 clientInst = packet->data->read<uint32>();

			PacketBuffer aBuffer(500);
			aBuffer.writeHeader("GameCharAgent", "GameCharInterface", gameUnknown1, 0, client->nClientInst, 0, 0x07);
			aBuffer.write<uint32>(data);
			aBuffer.write<uint32>(data1);
			/*
			00 = nothing
			02 = quest avaliable (! over head)
			04 = quest complete (? over head)
			*/
			
				aBuffer.write<uint8>(0x00);
			
			aBuffer.doItAll(client->clientSocket);
			
			break;
		}

	case 0x4C: // CinematicTransition
		{
			uint32 unk1 = packet->data->read<uint32>(); // 00 00 C3 50 
			uint32 clientInst = packet->data->read<uint32>(); // 11 01 89 CA 
			uint8 unk3 = packet->data->read<uint8>(); // 00

			break;
		}

	case 0x53:
		{
			/*
			Data of client packet:
			00 00 c3 50 00 06 9c e0 
			00 0a //stringlength
			7b 73 74 6f 63 6b 5f 34 38 7d //{stock_48}
			00 2d ad 4d
			*/
			uint32 data = packet->data->read<uint32>();
			uint32 obj = packet->data->read<uint32>();	//i think object id
			string command = packet->data->read<string>();
			uint32 data2 = packet->data->read<uint32>();
			if(command == "{stock_48}")
			{
				PacketBuffer aBuffer(2000);
				aBuffer.writeHeader("GameCharAgent", "GameCharInterface", gameUnknown1, 0, client->nClientInst, 0, 0x57);
				aBuffer.write<uint32>(data2);
				aBuffer.write<string>("<remoteformat id=\"6195\" category=\"50000\" key=\"gdVvZ+XDaiyqOA_OQ+_.\" knubot=\"388\"  ></remoteformat>");
				aBuffer.doItAll(client->clientSocket);

				aBuffer = PacketBuffer(500);
				aBuffer.writeHeader("GameAgent", "GameInterface", gameUnknown1, 0, client->nClientInst, 0, 0x00); 
				aBuffer.write<uint32>(0x0000001b);
				aBuffer.write<uint32>(0xa36d3b74);
				aBuffer.write<uint32>(0x0000c350);
				aBuffer.write<uint32>(client->nClientInst);
				aBuffer.write<uint32>(0x00040202);
				aBuffer.write<string>("Kneel");
				aBuffer.write<uint32>(0x3e4f4f3c);
				aBuffer.doItAll(client->clientSocket);

				if(!Database.insertItemEntry(client->charInfo.characterID))
				{
					Log.Error("Can't insert entry at player_items\n");
				}
			}
			if(command == "{stock_49}")
			{
				PacketBuffer aBuffer(2000);
				aBuffer.writeHeader("GameCharAgent", "GameCharInterface", gameUnknown1, 0, client->nClientInst, 0, 0x57);
				aBuffer.write<uint32>(data2);
				aBuffer.write<string>("<remoteformat id=\"6196\" category=\"50000\" key=\"Uj1v&amp;fwEoqN_lA8bnWOp\" knubot=\"388\"  ></remoteformat>");
				aBuffer.doItAll(client->clientSocket);
			}
			if(command == "{stock_50}")
			{
				PacketBuffer aBuffer(2000);
				aBuffer.writeHeader("GameCharAgent", "GameCharInterface", gameUnknown1, 0, client->nClientInst, 0, 0x57);
				aBuffer.write<uint32>(data2);
				aBuffer.write<string>("<remoteformat id=\"6197\" category=\"50000\" key=\"O,AyOT)I7kT+ECrK(V.?\" knubot=\"388\"  ></remoteformat>");
				aBuffer.doItAll(client->clientSocket);
			}
			if(command == "{stock_51}")
			{
				PacketBuffer aBuffer(2000);
				aBuffer.writeHeader("GameCharAgent", "GameCharInterface", gameUnknown1, 0, client->nClientInst, 0, 0x57);
				aBuffer.write<uint32>(data2);
				aBuffer.write<string>("<remoteformat id=\"6198\" category=\"50000\" key=\"K&#39;B*LKSZ*)%&#92;mr^^wf0^\" knubot=\"388\"  ></remoteformat>");
				aBuffer.doItAll(client->clientSocket);
			}
			if(command == "{stock_52}")
			{
				PacketBuffer aBuffer(2000);
				aBuffer.writeHeader("GameCharAgent", "GameCharInterface", gameUnknown1, 0, client->nClientInst, 0, 0x57);
				aBuffer.write<uint32>(data2);
				aBuffer.write<string>("<remoteformat id=\"6199\" category=\"50000\" key=\"!-u62.+NE`(`enfqa-MH\" knubot=\"388\"  ></remoteformat>");
				aBuffer.doItAll(client->clientSocket);
			}
			if(command == "{stock_56}")
			{
				PacketBuffer aBuffer(2000);
				aBuffer.writeHeader("GameCharAgent", "GameCharInterface", gameUnknown1, 0, client->nClientInst, 0, 0x57);
				aBuffer.write<uint32>(data2);
				aBuffer.write<string>("<remoteformat id=\"6200\" category=\"50000\" key=\"l0YEA(3XEbloy4HkuHFC\" knubot=\"388\"  ></remoteformat>");
				aBuffer.doItAll(client->clientSocket);
			}
			break;
		}

	case 0x62:
		{
			uint8 pack1[] = { 
				0x00, 0x00, 0x37, 0x2e, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x00, 0x0b, 0xbc, 0x46, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x04, 0x00, 0x0b, 0xbc, 0x4b, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x04, 0x00, 0x0b, 0xbc, 0x47, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0a, 0x00, 0x00, 0x00, 0x04, 0x00, 0x0b, 0xbc, 0x48, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c, 0x00, 0x00, 0x00, 0x04, 0x00, 0x0b, 0xbc, 0x49, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x64, 0x00, 0x00, 0x00, 0x04, 0x00, 0x0b, 0xbc, 0x46, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x65, 0x00, 0x00, 0x00, 0x04, 0x00, 0x0b, 0xbc, 0x4b, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x66, 0x00, 0x00, 0x00, 0x04, 0x00, 0x0b, 0xbc, 0x47, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x6e, 0x00, 0x00, 0x00, 0x04, 0x00, 0x0b, 0xbc, 0x48, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x70, 0x00, 0x00, 0x00, 0x04, 0x00, 0x0b, 0xbc, 0x49, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x4e, 0x20, 0x00, 0x00, 0x00, 0x04, 0x00, 0x32, 0x9b, 0x83, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x4e, 0x21, 0x00, 0x00, 0x00, 0x04, 0x00, 0x39, 0xe7, 0x83, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x4e, 0x22, 0x00, 0x00, 0x00, 0x04, 0x00, 0x38, 0x15, 0xc0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
			};
			PacketBuffer aBuffer(500);
			aBuffer.writeHeader("GameCharAgent", "GameCharInterface", gameUnknown1, 0, client->nClientInst, 0, 0x6b);
			aBuffer.writeArray(pack1, sizeof(pack1));
			aBuffer.doItAll(client->clientSocket);

			break;
		}

	case 0x6A: // SetHideHelmet
		{
			uint8 unk1 = packet->data->read<uint8>(); // 00
			uint32 unk2 = packet->data->read<uint32>(); // 00 00 00 3B
			uint32 unk3 = packet->data->read<uint32>(); // 6E 2B 6E 7C

			Log.Notice("Received Opcode: 0x6A!\n");

			break;
		}

	case 0x6B: // SetHideCloak
		{
			uint8 unk1 = packet->data->read<uint8>(); // 00
			uint32 unk2 = packet->data->read<uint32>(); // 00 00 00 3B
			uint32 unk3 = packet->data->read<uint32>(); // 21 6A F8 BB

			Log.Notice("Received Opcode: 0x6B!\n");

			break;
		}

	case 0x6C: // SetHideInspectOption
		{
			uint8 unk1 = packet->data->read<uint8>(); // 00
			uint32 unk2 = packet->data->read<uint32>(); // 00 00 00 3B
			uint32 unk3 = packet->data->read<uint32>(); // F5 11 23 60

			Log.Notice("Received Opcode: 0x6C!\n");

			break;
		}
	case 0x72:
		{
			uint8 unk1 = packet->data->read<uint8>(); // 00

			Log.Debug("Received Opcode: 0x70!\n"); 

			break;
		}
	case 0x73:
		{
			uint8 unk1 = packet->data->read<uint8>(); // 00

			Log.Debug("Received Opcode: 0x71!\n"); 

			break;
		}
	case 0x74:
		{
			uint8 unk1 = packet->data->read<uint8>(); // 00

			Log.Debug("Received Opcode: 0x72!\n"); 

			break;
		}

	default:
		{
			Log.Warning("Unknown Packet With Opcode: 0x%08X (%s):\n", packet->opcode, packet->receiver.c_str());
			Log.Warning("%s\n\n", String::arrayToHexString(packet->data->buffer, packet->data->bufferLength).c_str());

			break;
		}
	}
}