

bool textscript			= false;
bool collectionlibrary	= false;
bool staticapoints2		= false;
bool rivers				= false;
bool patrols			= false;
bool boundedareas		= false;
bool staticaipoints		= false;
bool exportPNG			= false;
bool exportPNG2			= false;
bool scriptgroup		= false;
bool animsys			= false;