/*
Project Faolan a Simple and Free Server Emulator for Age of Conan.
Copyright (C) 2009, 2010, 2011, 2012 The Project Faolan Team

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef COMMON_H
#define COMMON_H

#ifdef HAVE_CONFIG_H
#	include <config.h>
#endif

#define PLATFORM_WIN32 0
#define PLATFORM_UNIX  1
#define PLATFORM_APPLE 2

#if defined(__WIN32__) || defined(WIN32) || defined (_WIN32)
#	define PLATFORM PLATFORM_WIN32
#	define WIN32_LEAN_AND_MEAN
#	define _WIN32_WINNT 0x0501
#elif defined(__APPLE_CC__)
#	define PLATFORM PLATFORM_APPLE
#elif defined (__linux__)
#	define PLATFORM PLATFORM_UNIX
#else
#	pragma error "FATAL ERROR: Unknown OS."
#endif

#define COMPILER_MICROSOFT 0
#define COMPILER_GNU       1
#define COMPILER_BORLAND   2

#ifdef _MSC_VER
#	define COMPILER COMPILER_MICROSOFT
#elif defined(__BORLANDC__)
#	define COMPILER COMPILER_BORLAND
#elif defined(__GNUC__)
#	define COMPILER COMPILER_GNU
#else
#	pragma error "FATAL ERROR: Unknown compiler."
#endif

#define PLATFORM_32BIT 32
#define PLATFORM_64BIT 64

#if _WIN64 || __amd64__ || __ia64__
#   define BITPLATFORM PLATFORM_64BIT
#else
#   define BITPLATFORM PLATFORM_32BIT
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////

#if COMPILER == COMPILER_GNU && __GNUC__ >= 3
#	include <ext/hash_map>
#	define __fastcall __attribute__((__fastcall__))
#else
#	include <hash_map>
#endif

#ifdef _STLPORT_VERSION
#	define HM_NAMESPACE std
#elif COMPILER == COMPILER_MICROSOFT && _MSC_VER >= 1300 // msvc71
#	define HM_NAMESPACE stdext
#elif COMPILER == COMPILER_GNU && __GNUC__ >= 3
#	define HM_NAMESPACE __gnu_cxx

namespace __gnu_cxx 
{
	template<> struct hash<unsigned long long> 
	{
		size_t operator()(const unsigned long long &__x) const { return (size_t)__x; }
	};

	template<typename T> struct hash<T *> 
	{
		size_t operator()(T * const &__x) const { return (size_t)__x; }
	};
};

#else
#	define HM_NAMESPACE std
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////

#if COMPILER == COMPILER_MICROSOFT
#	define strcasecmp stricmp

#	define I64FMT "%016I64X"
#	define I64FMTD "%I64u"
#	define SI64FMTD "%I64d"

#	define snprintf _snprintf
#	define atoll __atoi64

#	pragma warning(disable: 4251)
#	pragma warning(disable: 4275)
#	pragma warning(disable: 4996)
#else
//#	define STRCASECMP strcasecmp
#	define stricmp strcasecmp
#	define strnicmp strncasecmp

#	define I64FMT "%016llX"
#	define I64FMTD "%llu"
#	define SI64FMTD "%lld"

#   define Sleep sleep
#endif

#if COMPILER == COMPILER_MICROSOFT
#	ifdef COMMON_EXPORT
#	  define FAOLANEXPORTED __declspec(dllexport)
#	else
#	  define FAOLANEXPORTED __declspec(dllimport)
#	endif
#else 
#	define FAOLANEXPORTED 
#endif 

////////////////////////////////////////////////////////////////////////////////////////////////////////

typedef int			int32;
typedef short       int16;
typedef char        int8;

typedef unsigned int        uint32;
typedef unsigned short      uint16;
typedef unsigned char       uint8;

#if COMPILER == COMPILER_MICROSOFT
typedef __int64   int64;
typedef unsigned __int64   uint64;
#else
typedef long long int64;
typedef unsigned long long  uint64;
#endif

#define atol(a) strtoul(a, NULL, 10)
#define STRINGIZE(a) #a

////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <boost/foreach.hpp>
#define foreach BOOST_FOREACH

#define FaolanBanner\
	"-------------------------------------------------------------------------------\n"\
	"|  ####  ####   ###    # #### ### #####    ####   #    ###  #      #   #   #  |\n"\
	"|  #   # #   # #   #   # #    #     #      #     # #  #   # #     # #  ##  #  |\n"\
	"|  ####  ####  #   #   # #### #     #      #### #   # #   # #    #   # # # #  |\n"\
	"|  #     #  #  #   #   # #    #     #      #    ##### #   # #    ##### #  ##  |\n"\
	"|  #     #   #  ###  ### #### ###   #      #    #   #  ###  #### #   # #   #  |\n"\
	"-------------------------------------------------------------------------------\n"

#define FAOLAN_CATCH\
    catch(const std::exception &ex)\
    {\
        printf("Exception thrown in file: %s on line: %i Message:\n%s\n",\
            __FILE__, __LINE__, ex.what());\
    }

#endif